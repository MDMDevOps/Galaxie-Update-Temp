jQuery( function( $ ) {
    'use strict';

    var ShowPasswords = function() {
        $.map( $( '.mdm_galaxie_connector_settings .mdm-password-field' ), function( el ) {
            return new PasswordField( el );
        });

        function PasswordField( el ) {

            var $el = $( el );
            var $field = $el.find( 'input[type=password]' );
            var $button = $el.find( 'button' );

            var displayPassword = function() {
                $field.attr( 'type', 'text' );
                $button.html( 'Hide' ).blur();
                return;
            };

            var hidePassword = function() {
                $field.attr( 'type', 'password' );
                $button.html( 'Show' ).blur();
                return;
            };

            var toggleState = function() {
                if( $field.attr( 'type' ) === 'password' ) {
                    displayPassword();
                    return;
                } else {
                    hidePassword();
                    return;
                }
            };

            $button.on( 'click', toggleState );
        }
    }();

    var ClearLog = ( function() {
        var $wrapper = $( '#mdm_galaxie_connector_errors' );
        var $button  = $wrapper.find( '#clear_log' );
        var $view    = $wrapper.find( '#errors' );



        $button.on( 'click', clearlog );

        function clearlog( event ) {
            var json, ajax;
            event.preventDefault();
            ajax = $.post( wpgcajax.ajaxurl, { action : 'clearlog' } );
            ajax.done( function( response ) {
                try {
                    json = JSON.parse( response );
                    if( json === true ) {
                        $view.html('');
                    } else {
                        alert( 'Unable to clear error log' );
                    }
                } catch( error ) {

                }
            });

        }
    })();

    var ClearCache = ( function() {
        var $wrapper = $( '#mdm_galaxie_connector_errors' );
        var $button  = $wrapper.find( '#clear_cache' );
        var $view    = $wrapper.find( '#errors' );



        $button.on( 'click', clearlog );

        function clearlog( event ) {
            var json, ajax;
            event.preventDefault();
            ajax = $.post( wpgcajax.ajaxurl, { action : 'clearcache' } );
            ajax.done( function( response ) {
                try {
                    json = JSON.parse( response );
                    if( json === true ) {
                        alert( 'Cache Cleared' );
                    } else {
                        alert( 'Unable to clear error log' );
                    }
                } catch( error ) {
                    alert( 'Unable to clear error log' );
                }
            });

        }
    })();

}); // end document ready