// Protect the global namespace
if( $ ) { $.noConflict(); }
// Document ready function
jQuery( document ).ready(function($) {
    'use strict';
    var Galaxie = ( function() {
        var filters, data, dataset, modal, units, toggles;
        // If we have nothing on this page that we can use, let's bail
        if( $( '.mdmgc' ).length === 0 ) {
            return;
        }
        // Define Filters
        function Filter( $el ) {
            $el.datatype = $el.data( 'type' ) || 'int';
            $el.operator = $el.data( 'compare' ) || '=';
            $el.filter = function( values ) {
                var value, field;
                var dataset = [];
                // Get length of dataset
                var length = values.length;
                // Loop through each item in the dataset
                for( var index = 0; index < length; index++ ) {
                    // Validate value based on type
                    switch( $el.datatype ) {
                        case 'int' :
                            field = parseInt( values[index][ $el.attr( 'name' ) ] );
                            value = parseInt( $el.val() );
                            break;
                        case 'doubleint' :
                            field = parseInt( values[index][ $el.attr( 'name' ) ] );
                            value = $el.val().split(':');
                            for( var i = 0; i < value.length; i++ ) {
                                value[i] = parseInt( value[i] );
                            }
                            break;
                        default :
                            field = '';
                            value = '';
                            break;
                    }
                    // Parse filter based on comparison operator
                    switch( $el.operator ) {
                        case '>' :
                            if( field > value ) {
                                dataset.push( values[index] );
                            }
                            break;
                        case '<' :
                            if( field < value ) {
                                dataset.push( values[index] );
                            }
                            break;
                        case '<=' :
                            if( field <= value ) {
                                dataset.push( values[index] );
                            }
                            break;
                        case '>=' :
                            if( field >= value ) {
                                dataset.push( values[index] );
                            }
                            break;
                        case '<<' :
                            if( field >= value[0] && field <= value[1] ) {
                                dataset.push( values[index] );
                            }
                            break;
                        default :
                            // Default assumes = operator
                            if( field === value ) {
                                dataset.push( values[index] );
                            }
                            break;
                    }
                }
                // Finally, return the filtered dataset
                return dataset;
            };
            $el.sort = function( data ) {
                // Create a copy of the data object
                var display = $.extend( true, {}, data );
                // Loop through each filter, filtering the dataset
                for( var index = 0; index < filters.length; index++ ) {
                    // If blank, we can bail
                    if( filters[index].val().length === 0 ) {
                        continue;
                    }
                    display.data = filters[index].filter( display.data );
                }
                return display;
            };
            return $el;
        }
        // Define Request
        function Request( data, callback ) {
            var json, ajax;
            ajax = $.post( wpgcajax.ajaxurl, data );
            ajax.done( function( response ) {
                try {
                    json = JSON.parse( response );
                    return callback( json );
                } catch( error ) {
                    json = {
                        'status' : 'Unable to render response',
                        'error'  : error,
                        'data'   : null,
                    };
                    return callback( json );
                }
            });
        }
        // Define View
        function View( $el ) {
            return {
                template  : $el.find( '[type="text/x-handlebars-template"]' ).first().html(),
                cardview  : $el.find( '#unit_card_template' ).html(),
                tableview : $el.find( '#unit_table_template' ).html(),
                render    : function( json ) {
                    // Make sure a valid dataset was passed in
                    if( typeof json === 'undefined' ) {
                        json = data;
                    }
                    var temp = Handlebars.compile( this.template );
                    $el.html( temp( json.data ) );
                    $el.find( 'table' ).DataTable( {
                        'autoWidth' : false,
                        'paging'    : false,
                        'searching' : false,
                        'stateSave' : true,
                        'aoColumnDefs': [{
                             'bSortable': false,
                             'aTargets': ['nosort']
                         }]
                    });
                    return $el;
                }
            };
        }
        // Define Model
        function Modal( $el ) {
            var mview, modal, unit, units, $next, $previous;
            $previous = $el.find( '.previous' );
            $next = $el.find( '.next' );

            // Create modal object
            modal = new View( $el.find( '#mdmgc_modal_body' ) );
            // Bind handlers
            $( 'body' ).on( 'click', 'a[rel="modal"]', up );
            $el.on( 'click', down );
            function up( event ) {
                event.preventDefault();
                units = dataset || data;
                unit = $.extend( true, {}, units );
                unit.data = unit.data[ $( event.currentTarget ).data( 'index' ) ];
                unit.data.order = $( event.currentTarget ).data( 'index' );
                modal.render( unit );
                // $el.find( '.close' ).one( 'click', down );
                $el.fadeIn( 300 );
            }
            function down( event ) {
                var $target = $( event.target );
                // If we clicked OUTSIDE the modal, we can close it...
                if( $el.find( $target ).length === 0 ) {
                    return close();
                }
                // If we clicked the close button
                if( $target.hasClass( '.close' ) || $target.closest( '.close' ).length ) {
                    return close();
                }
                // // If target is a link
                // if( $target.is( 'a' ) || $target.closest( 'a' ).length ) {
                //     return true;
                // }
                // Else, don't do anything
                return true;
            }
            function close() {
                $el.fadeOut( 300 );
            }
        }
        // Define Toggle
        function Toggle( $el, view ) {
            var viewtype = $el.data( 'viewtype' ) || 'cardview';
            $el.on( 'click', toggle );
            function toggle( event ) {
                view.template = view[viewtype];
                view.render( dataset );
                for( var i = 0; i < toggles.length; i++ ) {
                    toggles[i].removeClass( 'active' );
                }
                $el.addClass( 'active' );
            }
            return $el;
        }
        function sort( event ) {
            dataset = event.data.filter.sort( data );
            units.render( dataset );
        }
        // Kickoff the app
        var init = ( function() {
            // Create objects
            filters = $.map( $( '#mdmgcfilters input, #mdmgcfilters select' ), function( el ) {
                return new Filter( $( el ) );
            });
            modal = new Modal( $( '#mdmgc_modal' ) );
            units = new View( $( '#mdmgc_units_view' ) );
            toggles = $.map( $( '#toggle-view button' ), function( el ) {
                return new Toggle( $( el ), units );
            });
            // Bind events
            for( var i = 0; i < filters.length; i++ ) {
                filters[i].on( 'change', { filter : filters[i] }, sort );
            }
            // Set initial template
            units.template = units.cardview;
            // Request data
            Request( { action : 'query_listings' }, function( response ) {
                data = response;
                units.render( data );
            });
        })();
    })();
});