<?php
/**
 * The markup to display the settings page
 * @author  Mid-West Family Marketing
 * @link    http://midwestfamilymarketing.com
 * @since   1.0.0
 */
?>

<div class="wrap <?php echo sprintf( '%s_settings', $this->plugin_name ); ?>">
    <form method="post" action="options.php">
        <?php wp_nonce_field( 'update-options' ); ?>
        <?php settings_fields( $this->plugin_name ); ?>
        <?php do_settings_sections( $this->plugin_name ); ?>
        <?php submit_button(); ?>
    </form>
</div>

<div class="wrap bootstrapped" id="<?php echo sprintf( '%s_errors', $this->plugin_name ); ?>">
<h2>Error Log</h2>
<hr>
<textarea name="errors" id="errors" class="widefat formcontrol" cols="30" rows="30" readonly>
    <?php
        if( file_exists( $this->plugin_path . 'logs/error.log' ) ) {
            echo file_get_contents( $this->plugin_path . 'logs/error.log' );
        }
    ?>
</textarea>
<button id="clear_log" class="button button-primary pull-right">Clear Log</button>
<button id="clear_cache" class="button button-primary pull-right">Clear Cache</button>
</div>