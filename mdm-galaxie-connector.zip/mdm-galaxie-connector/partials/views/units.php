<section id="mdmgc_units_view" class="mdmgc">
    <?php include $this->plugin_path . 'partials/templates/unit_card.html'; ?>
    <?php include $this->plugin_path . 'partials/templates/unit_table.html'; ?>
</section>

<section id="mdmgc_modal" class="mdmgc">
    <div class="modal">
        <div class="modal-header">
            <button class="close"><span class="fa fa-times" aria-hidden="true"></span></button>
        </div>
        <div id="mdmgc_modal_body" class="modal-body">
            <?php include $this->plugin_path . 'partials/templates/modal_body.html'; ?>
        </div>
        <div class="modal-footer">
        <!-- Possibly some footer stuff here in the future... -->
        </div>
    </div>
</section>