<?php
/**
 * The plugin bootstrap file
 * This file is read by WordPress to generate the plugin information in the plugin admin area.
 * This file also defines plugin parameters, registers the activation and deactivation functions, and defines a function that starts the plugin.
 * @link    http://midwestfamilymarketing.com
 * @since   1.0.0
 * @package mdm_galaxy_connector
 *
 * @wordpress-plugin
 * Plugin Name: Galaxy Apartments Data Connector
 * Plugin URI:  http://midwestfamilymarketing.com
 * Description: Provide a connection to a private database for Galaxie Apartments
 * Version:     1.1.2
 * Author:      Mid-West Family Marketing
 * Author URI:  http://midwestfamilymarketing.com
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: mdm_galaxy_connector
 * Domain Path: /i18n
 */

// If this file is called directly, ABORT ABORT ABORT
if ( !defined( 'WPINC' ) ) {
    die( 'Bugger Off Script Kiddies!' );
}

/**
 * Begins execution of the plugin.
 * @since 1.0.0
 */

if( !function_exists( 'init_mdm_galaxie_connector_plugin' ) ) {
    function init_mdm_galaxie_connector_plugin() {
        // Include our main plugin file
        include_once plugin_dir_path( __FILE__ ) . 'core/class_mdm_galaxie_connector.php';
        // Instantiate our plugin
        $plugin = new Mdm_Galaxie_Connector();
        // And finally, run it...
        $plugin->run();
    }
    // Let's kick this puppy off...
    init_mdm_galaxie_connector_plugin();
}