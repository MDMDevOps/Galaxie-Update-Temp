#MDM Galaxie / MPM Database Connector

##ToDo:

- Make proper README.md file
- Create Wiki for documentation & user guide