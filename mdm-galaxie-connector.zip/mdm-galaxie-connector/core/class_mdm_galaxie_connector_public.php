<?php

/**
 * Defines public functions
 * @link  http://midwestfamilymarketing.com
 * @since 1.0.0
 */

class Mdm_Galaxie_Connector_Public extends Mdm_Galaxie_Connector {

    /**
     * Exceptions
     * @since 1.0.0
     * @access protected
     * @var (object) $exception : Used to flag if an exception has occured
     */
    protected $exception;

    /**
     * Database Connection
     * @since 1.0.0
     * @access protected
     * @var (pdo object) $dbconnection : The connection to the database
     */
    protected $dbconnection;

    /**
     * Constructor Function
     * Calls parent constructor, which sets common fields
     * @since 1.0.0
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Enqueue admin site css files
     * @since 1.0.0
     * @see https://developer.wordpress.org/reference/functions/wp_enqueue_style/
     */
    public function enqueue_styles() {
        wp_enqueue_style( sprintf( '%s_public', $this->plugin_name ), $this->plugin_url . 'styles/dist/public.min.css', array(  ), $this->plugin_version, 'all' );
    }

    /**
     * Enqueue and localize admin site javascript
     * @since 1.0.0
     * @see https://developer.wordpress.org/reference/functions/wp_enqueue_script/
     * @see https://developer.wordpress.org/reference/functions/wp_localize_script/
     */
    public function enqueue_scripts() {
        // If we made it here, we can enqueue & localize javascript
        wp_register_script( 'datatables', $this->plugin_url . 'scripts/dist/datatables.min.js', array( 'jquery' ), $this->plugin_version, true );
        wp_register_script( 'handlebars', $this->plugin_url . 'scripts/dist/handlebars.min.js', array( 'datatables' ), $this->plugin_version, true );
        wp_register_script( sprintf( '%s_public', $this->plugin_name ), $this->plugin_url . 'scripts/dist/public.min.js', array( 'jquery', 'datatables', 'handlebars' ), $this->plugin_version, true );

        wp_enqueue_script( sprintf( '%s_public', $this->plugin_name ) );
        wp_localize_script( sprintf( '%s_public', $this->plugin_name ), 'wpgcajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php') ) );
    }

    /**
     * Connect to external database
     * Uses parameters set by user, and saved as WordPress options
     * @see http://php.net/manual/en/pdo.construct.php
     */
    private function connect_to_database() {
        // Make sure we have our settings
        if( !isset( $this->plugin_settings ) ) {
            $this->plugin_settings = $this->get_plugin_settings();
        }
        // Try to connect
        try {
            // 1. Make connection to database
            $this->dbconnection = new PDO( sprintf( 'mysql:host=%1$s;dbname=%2$s;charset=utf8;', $this->plugin_settings['db_host'], $this->plugin_settings['db_name'] ), $this->plugin_settings['db_user'], $this->plugin_settings['db_pass'] );
            // 2. Set default fetch mode to fetch objects
            $this->dbconnection->setAttribute( PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ );
            // 3. Set the error mode to throw catchable exceptions
            $this->dbconnection->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        } catch( PDOException $e ) {
            $this->dbconnection = null;
            $this->handle_error( $e );
        }
    }

    /**
     * Handle Errors
     * Logs errors to text file located within plugin
     * @see http://php.net/manual/en/function.error-log.php
     */
    private function handle_error( $e ) {
        // Log the error to our plugins log file
        $d = new DateTime();
        $message  = '================================================================================' . "\n";
        $message .= 'Error : ' . $e->getMessage() . "\n";
        $message .= 'File  : ' . $e->getFile() . "\n";
        $message .= 'Line  : ' . $e->getLine() . "\n";
        $message .= 'Time  : ' . $d->format( 'Y-m-d h:i:s' ) . "\n";
        error_log( $message, 3, $this->plugin_path . 'logs/error.log' );
        $this->exception = true;
        exit();
    }

    public function query_units_shortcode( $atts = array() ) {
        ob_start();
        $units = $this->query_units();
        include $this->plugin_path . 'partials/views/units.php';
        return ob_get_clean();
    }

    public function unit_filters_shortcode( $atts = array() ) {
        ob_start();
        include $this->plugin_path . 'partials/pages/filters.php';
        return ob_get_clean();
    }

    public function query_units_ajax() {
        $response = array(
            'status' => 'success',
            'error'  => false,
            'data'   => $this->query_units(),
        );
        if( $this->exception === true ) {
            $response = array(
                'status' => 'failure',
                'error'  => true,
                'data'  => array(),
            );
        }
        echo json_encode( $response );
        exit();
    }

    public function query_units() {
        $cached = get_transient( sprintf( '%s_units', $this->plugin_name ) );
        if( $cached ) {
            // return $cached;
        }
        // Get Units sorted by floorplans
        $units = $this->fetch_units();
        // Cache theme
        set_transient( sprintf( '%s_units', $this->plugin_name ), $units, 60 * 60 );
        // Return the floorplans
        return $units;
    }

    /**
     * Fetch all apartments
     */
    public function fetch_units( $query = 'all_units', $id = null ) {
        // Make sure we have our settings
        if( !isset( $this->plugin_settings ) ) {
            $this->plugin_settings = $this->get_plugin_settings();
        }
        $results =  $this->query_database( $query, $id );
        $units   = array();
        foreach( $results as $result ) {
            $result->meta = $this->query_database( 'unit_meta', $result->id );
            $result->rent = $this->query_database( 'unit_rent', $result->id );
            $newunit = new Mdm_Galaxie_Connector_Unit( $result, $this->plugin_settings );
            if( strtolower( $newunit->availablefuture ) === 'yes' ) {
            	$units[] = $newunit;
            }
        }

        return $units;
    }

    /**
     * Query external database
     * Connect to database if appropriate, and perform pdo query
     * @param (string) $query : The action or type of query to perform
     * @param (int) $id : The record ID if quering a single record
     * @see http://php.net/manual/en/pdo.prepare.php
     * @see http://php.net/manual/en/pdostatement.bindparam.php
     */
    public function query_database( $query = '', $id = null ) {
        if( empty( $query ) ) {
            return;
        }
        // Connect to database
        if( !isset( $this->dbconnection ) && $this->exception !== true ) {
            $this->connect_to_database();
        }
        // Get query string
        $query_string = $this->get_database_query( $query );
        // Get results from database
        $results = array();
        try {
            $records = $this->dbconnection->prepare( $query_string );
            if( !empty( $id ) ) {
                $records->bindParam( ':unitid', $id, PDO::PARAM_INT );
            }
            if( $query === 'unit_rent' ) {
                $datetime = new DateTime();
                $datetime->format( 'Y-m-d' );
                $today = $datetime->format( 'Y-m-d' );
                $records->bindParam( ':today', $today , PDO::PARAM_STR );
            }
            $records->execute();
            foreach( $records as $record ) {
                if( empty( $record->id ) ) {
                    $results[] = $record;
                } else {
                    $results[ $record->id ] = $record;
                }
            }
            $this->dbconnection = null;
        } catch( PDOException $e ) {
            $this->handle_error( $e );
        }
        return $results;
    }

    private function get_database_query( $query ) {
        $queries = array(
            'all_units' => "SELECT DISTINCT units.unitid as id,
                                units.propid,
                                units.name,
                                units.street1,
                                units.city,
                                units.sqft,
                                units.image1path,
                                units.image2path,
                                unittypes.unittype as type
                                FROM `units`
                                    INNER JOIN `unittypes` on unittypes.unittypeid = units.unittypeid
                                    	WHERE units.propid = 1611
                                        ORDER BY units.unitid",
            'unit_meta' => "SELECT DISTINCT unituserdefinedvalues.userdefinedid as id,
                                unituserdefinedvalues.value as value,
                                unituserdefined.name as name
                                FROM `unituserdefinedvalues`
                                    INNER JOIN `unituserdefined` on unituserdefined.userdefinedid = unituserdefinedvalues.userdefinedid
                                    WHERE unituserdefinedvalues.unitid = :unitid",
            'unit_rent' => "SELECT amount FROM `marketrent` WHERE unitid = :unitid AND `fromdate` <= :today ORDER BY `fromdate` DESC Limit 0,1",
        );
        if( isset( $queries[ strtolower( $query ) ] ) ) {
            return $queries[ strtolower( $query ) ];
        }
        return false;
    }
} // end class