<?php

/**
 * Defines ajax functions
 * @link  http://midwestfamilymarketing.com
 * @since 1.0.0
 */

class Mdm_Galaxie_Connector_Ajax extends Mdm_Galaxie_Connector {

    /**
     * Constructor Function
     * Calls parent constructor, which sets common fields
     * @since 1.0.0
     */
    public function __construct() {
        parent::__construct();
    }
} // end class