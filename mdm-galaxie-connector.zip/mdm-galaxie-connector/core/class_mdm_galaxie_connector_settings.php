<?php

/**
 * Defines the settings of the plugin
 * @link  http://midwestfamilymarketing.com
 * @since 1.0.0
 */

class Mdm_Galaxie_Connector_Settings extends Mdm_Galaxie_Connector {

    /**
     * Constructor Function
     * Calls parent constructor, which sets common fields
     * @since 1.0.0
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Get default settings
     * @since 1.0.0
     * @static
     */
    public static function get_default_settings() {
        $default_options = array(
            'api_key' => null,
            'db_host' => null,
            'db_name' => null,
            'db_user' => null,
            'db_pass' => null,
            'showing' => null,
            'application' => null,
            'email' => null,
            'facebook' => null,
            'twitter' => null,
            'instagram' => null,
            'pinterest' => null,
            'gplus'     => null,
        );
        return $default_options;
    }

    /**
     * Get the setting fields used for the settings page
     * @since 1.0.0
     * @see https://codex.wordpress.org/Function_Reference/checked
     */
    protected function get_settings_fields() {
        // Get settings from database
        if( !isset( $this->plugin_settings ) ) {
            $this->plugin_settings = $this->get_plugin_settings();
        }
        // Define Fields
        $fields = array(
            'api_key'     => array(
               'title'       => __( 'API Key', $this->plugin_name ),
               'label'       => null,
               'type'        => 'text',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[api_key]', $this->plugin_name ),
               'section'     => 'general',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => sprintf( '%s%s %s%s', __( 'Enter your GitHub', $this->plugin_name ), '<a href="https://github.com/blog/1509-personal-api-tokens" target="_blank">', __( 'Personal Access Token', $this->plugin_name ), '</a>' ),
               'placeholder' => null,
               'priority'    => array( 'global', 'network' ),
               'value'       => $this->plugin_settings['api_key'],
            ),
            'db_host'     => array(
               'title'       => __( 'Database Host', $this->plugin_name ),
               'label'       => null,
               'type'        => 'text',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[db_host]', $this->plugin_name ),
               'section'     => 'database',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['db_host'],
            ),
            'db_name'     => array(
               'title'       => __( 'Database Name', $this->plugin_name ),
               'label'       => null,
               'type'        => 'text',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[db_name]', $this->plugin_name ),
               'section'     => 'database',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['db_name'],
            ),
            'db_user'     => array(
               'title'       => __( 'Database User', $this->plugin_name ),
               'label'       => null,
               'type'        => 'text',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[db_user]', $this->plugin_name ),
               'section'     => 'database',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['db_user'],
            ),
            'db_pass'     => array(
               'title'       => __( 'Database Password', $this->plugin_name ),
               'label'       => null,
               'type'        => 'password',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[db_pass]', $this->plugin_name ),
               'section'     => 'database',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['db_pass'],
            ),
            'showing'     => array(
               'title'       => __( 'Showing Link', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[showing]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['showing'],
            ),
            'application'     => array(
               'title'       => __( 'Application Link', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[application]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['application'],
            ),
            'email'     => array(
               'title'       => __( 'Email', $this->plugin_name ),
               'label'       => null,
               'type'        => 'email',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[email]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['email'],
            ),
            'facebook'     => array(
               'title'       => __( 'Facebook', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[facebook]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['facebook'],
            ),
            'twitter'     => array(
               'title'       => __( 'Twitter', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[twitter]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['twitter'],
            ),
            'instagram'     => array(
               'title'       => __( 'Instagram', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[instagram]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['instagram'],
            ),
            'pinterest'     => array(
               'title'       => __( 'Pinterest', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[pinterest]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['pinterest'],
            ),
            'gplus'     => array(
               'title'       => __( 'Google Plus', $this->plugin_name ),
               'label'       => null,
               'type'        => 'url',
               'field_class' => 'widefat form-control',
               'field_id'    => sprintf( '%s[gplus]', $this->plugin_name ),
               'section'     => 'links',
               'before'      => '<div class="bootstrapped">',
               'after'       => '</div>',
               'description' => null,
               'placeholder' => null,
               'priority'    => array(),
               'value'       => $this->plugin_settings['gplus'],
            ),
        );
        return $fields;
    }

    /**
     * Register the settings page
     * @see https://developer.wordpress.org/reference/functions/add_options_page/
     * @since 1.0.0
     */
    public function register_settings_page() {
        add_options_page( __( 'Database Connecter', $this->plugin_name ), __( 'DB Connector', $this->plugin_name ), 'manage_options', $this->plugin_name, array( $this, 'display_settings_page' ) );
    }

    /**
     * Display the settings page
     * @since 1.0.0
     */
    public function display_settings_page() {
        include $this->plugin_path . 'partials/pages/settings.php';
    }

    /**
     * Register plugin settings with WordPress
     * @since 1.0.0
     * @see https://codex.wordpress.org/Function_Reference/register_setting
     * @see https://codex.wordpress.org/Function_Reference/add_settings_section
     * @see https://codex.wordpress.org/Function_Reference/add_settings_field
     */
    public function register_settings() {
        register_setting( $this->plugin_name, $this->plugin_name );
        // Add Section
        add_settings_section( 'general', __( 'Plugin Update Settings', $this->plugin_name ), array( $this, 'output_section_rule' ), $this->plugin_name );
        add_settings_section( 'database', __( 'Database Connection Settings', $this->plugin_name ), array( $this, 'output_section_rule' ), $this->plugin_name );
        add_settings_section( 'links', __( 'Social / Page Settings', $this->plugin_name ), array( $this, 'output_section_rule' ), $this->plugin_name );
        // Get fields
        $fields = $this->get_settings_fields();
        // Cycle through fields, and register each
        foreach( $fields as $key => $field ) {
            // Add field
            add_settings_field( $field['field_id'], $field['title'], array( $this, 'display_setting_field' ), $this->plugin_name, $field['section'], $field );
        }
    }


    /**
     * Output content above settings on settings page
     * @since 1.0.0
     */
    public function output_section_rule() {
        echo '<hr>';
    }

    /**
     * Display setting fields
     * Include appropriate markup based on the type of field being displayed
     * @since 1.0.0
     */

    public function display_setting_field( $field ) {
        // Display before text
        if( isset( $field['before'] ) && !empty( $field['before'] ) ) {
            echo $field['before'];
        }
        // Display appropriate input
        switch( $field['type'] ) {
            case 'text' :
                include $this->plugin_path . 'partials/inputs/text.php';
                break;
            case 'url' :
                include $this->plugin_path . 'partials/inputs/url.php';
                break;
            case 'number' :
                include $this->plugin_path . 'partials/inputs/number.php';
                break;
            case 'email' :
                include $this->plugin_path . 'partials/inputs/email.php';
                break;
            case 'checkbox' :
                include $this->plugin_path . 'partials/inputs/checkbox.php';
                break;
            case 'radio' :
                include $this->plugin_path . 'partials/inputs/radio.php';
                break;
            case 'password' :
                include $this->plugin_path . 'partials/inputs/password.php';
                break;
            case 'textarea' :
                include $this->plugin_path . 'partials/inputs/textarea.php';
                break;
            case 'select' :
                include $this->plugin_path . 'partials/inputs/select.php';
                break;
            case 'group' : // Recursively call this function with single fields
                foreach( $field['fields'] as $single ) {
                    $this->display_field( $single );
                }
                break;
            default :
                break;
        }
        // Display after text
        if( isset( $field['after'] ) && !empty( $field['after'] ) ) {
            echo $field['after'];
        }
    }
} // end class