<?php

class Mdm_Galaxie_Connector_Unit extends Mdm_Galaxie_Connector {

    public $sqft;
    public $images;
    public $airconditioner;
    public $airconditioneryearreplaced;
    public $alwaystrue;
    public $available;
    public $availableaug;
    public $availablefrom;
    public $availablefrom2;
    public $availablefuture;
    public $availablefuturefrom;
    public $availablefutureto;
    public $availableshortterm;
    public $availableshortterm2;
    public $availableshortwithrenewoption;
    public $availableshortwithrenewoption2;
    public $availablesublet;
    public $availablesublet2;
    public $availableto;
    public $availableto2;
    public $baths;
    public $beds;
    public $carpetcleaningco;
    public $carpetdetails;
    public $catsok;
    public $checkoutperson;
    public $city;
    public $cleaningco;
    public $commercialunitsubtype;
    public $contact;
    public $craigslistcatsok;
    public $craigslistdogsok;
    public $craigslistemail;
    public $craigslistnearestcrossstreet;
    public $craigslistprice;
    public $craigslisttitle;
    public $dateputonmarket;
    public $denloft;
    public $description;
    public $descriptionsublet;
    public $descriptionsublet2;
    public $dishwasherdetails;
    public $dishwasheryearreplaced;
    public $dockboatcolor;
    public $dockboatmakemodel;
    public $dockboatname;
    public $docksliplength;
    public $dockslipnumber;
    public $dockslipwidth;
    public $dockspecialutilityfee;
    public $dogsok;
    public $dryer;
    public $dryerdetails;
    public $dryeryearreplaced;
    public $electricaldetails;
    public $email;
    public $entryaccess;
    public $filtersize;
    public $fireplacedetails;
    public $flooringbasementfamilyroom;
    public $flooringbasementfamilyroomyearreplaced;
    public $flooringbath1;
    public $flooringbath1yearreplaced;
    public $flooringbath2;
    public $flooringbath2yearreplaced;
    public $flooringbath3;
    public $flooringbath3yearreplaced;
    public $flooringbedrooma;
    public $flooringbedroomayearreplaced;
    public $flooringbedroomb;
    public $flooringbedroombyearreplaced;
    public $flooringbedroomc;
    public $flooringbedroomcyearreplaced;
    public $flooringbedroomd;
    public $flooringbedroomdyearreplaced;
    public $flooringbedroome;
    public $flooringbedroomeyearreplaced;
    public $flooringbedroomf;
    public $flooringbedroomfyearreplaced;
    public $flooringbedroomg;
    public $flooringbedroomgyearreplaced;
    public $flooringbedroomh;
    public $flooringbedroomhyearreplaced;
    public $flooringden;
    public $flooringdenyearreplaced;
    public $flooringhallway;
    public $flooringhallwayyearreplaced;
    public $flooringkitchen;
    public $flooringkitchenyearreplaced;
    public $flooringlivingroom;
    public $flooringlivingroomyearreplaced;
    public $flooringloft;
    public $flooringloftyearreplaced;
    public $flooringporch;
    public $flooringporchyearreplaced;
    public $flooringstairs;
    public $flooringstairsyearreplaced;
    public $floorplan2;
    public $floorplan3;
    public $floorplanlower;
    public $floorplanmain;
    public $forrenttitle;
    public $frontpage1;
    public $frontpage2;
    public $frontpage3;
    public $frontpage4;
    public $frontpage5;
    public $frontpage6;
    public $frontpage7;
    public $frontpage8;
    public $frontpage9;
    public $frontpage10;
    public $furnitureavailable;
    public $garagedoorcode;
    public $id;
    public $incomerestrictions;
    public $issmokefree;
    public $keymaster;
    public $landlord;
    public $laundrydetails;
    public $laundrydryeramount;
    public $laundrynearbylocation;
    public $laundryserviceco;
    public $laundrywasheramount;
    public $location;
    public $mailboxnumber;
    public $maintenancemanagedbympm;
    public $manager;
    public $meta;
    public $mgepin;
    public $microwave;
    public $microwavedetails;
    public $microwaveyearreplaced;
    public $moveinnotes;
    public $moveoutnotes;
    public $name;
    public $nearestcrossstreet;
    public $nolongermanaging;
    public $obligations;
    public $occupancylimit;
    public $paint;
    public $paintdetails;
    public $paintingco;
    public $parking;
    public $parkingcompactcaronly;
    public $parkingdetails;
    public $parkingmotorcycleonly;
    public $parkingrestrictedhours;
    public $parkingunitsubtype;
    public $parkingwebdetails;
    public $pdfpacket;
    public $pestproblem;
    public $pets;
    public $price;
    public $primarycontactemail;
    public $property;
    public $refrigerator;
    public $refrigeratordetails;
    public $refrigeratoryearreplaced;
    public $rent;
    public $roofdetails;
    public $schools;
    public $section8;
    public $securitydeposit;
    public $shorttermamount;
    public $shorttermamount2;
    public $showonapplication;
    public $showonfrontpage;
    public $stove;
    public $stovedetails;
    public $stoveyearreplaced;
    public $street;
    public $temporarilyoffmarket;
    public $trashday;
    public $trashremovalresponsibility;
    public $turnovernotes;
    public $type;
    public $unitfloorplantype;
    public $utilitiesresidentresponsibility;
    public $vinyldetails;
    public $vt1;
    public $vt2;
    public $vt3;
    public $vt4;
    public $vt5;
    public $vt6;
    public $vt7;
    public $vt8;
    public $vt9;
    public $vt10;
    public $vt11;
    public $vt12;
    public $vt13;
    public $vt14;
    public $vt15;
    public $vt16;
    public $vt17;
    public $vt18;
    public $vt19;
    public $vt20;
    public $vtorder1;
    public $vtorder2;
    public $vtorder3;
    public $vtorder4;
    public $vtorder5;
    public $vtorder6;
    public $vtorder7;
    public $vtorder8;
    public $vtorder9;
    public $vtorder10;
    public $vtorder11;
    public $vtorder12;
    public $vtorder13;
    public $vtorder14;
    public $vtorder15;
    public $vtorder16;
    public $vtorder17;
    public $vtorder18;
    public $vtorder19;
    public $vtorder20;
    public $vttitle1;
    public $vttitle2;
    public $vttitle3;
    public $vttitle4;
    public $vttitle5;
    public $vttitle6;
    public $vttitle7;
    public $vttitle8;
    public $vttitle9;
    public $vttitle10;
    public $vttitle11;
    public $vttitle12;
    public $vttitle13;
    public $vttitle14;
    public $vttitle15;
    public $vttitle16;
    public $vttitle17;
    public $vttitle18;
    public $vttitle19;
    public $vttitle20;
    public $washerdetails;
    public $washeryearreplaced;
    public $washingmachine;
    public $waterhearteryearreplaced;
    public $waterheaterdetails;
    public $watersofteneryearreplaced;
    public $watersoftnerdetails;
    // Not from database
    public $floorplanimage;
    public $contacts;

    public function __construct( $unit, $settings ) {

        parent::__construct();

        $this->id       = !empty( $unit->id ) ? $unit->id : null;
        $this->property = !empty( $unit->propid ) ? $unit->propid : null;
        $this->name     = !empty( $unit->name ) ? $unit->name : null;
        $this->street   = !empty( $unit->street1 ) ? $unit->street1 : null;
        $this->city     = !empty( $unit->city ) ? $unit->city : null;
        $this->type     = !empty( $unit->type ) ? $unit->type : null;
        $this->sqft     = !empty( $unit->sqft ) ? $unit->sqft : null;
        $this->sqft     = !empty( $unit->sqft ) ? $unit->sqft : null;
        $this->rent     = !empty( $unit->rent ) ? $this->format_rent( $unit->rent ) : 'n/a';
        // Parse social links
        $this->contacts = $this->parse_contacts( $settings );
        // parse meta fields
        $this->parse_meta( $unit );
        // Parse Images
        $this->images = $this->parse_images( $unit );
        // Adjust beds to integer
        $this->beds = intval($this->beds);
        // Adjust baths
        $this->baths = $this->parse_baths( $this->baths );
        // Get floor plan image(s)
    }

    private function parse_contacts( $settings ) {
        $contacts = array(
            'showing'     => isset( $settings['showing'] ) && !empty( $settings['showing'] ) ? esc_url_raw( $settings['showing'] ) : null,
            'application' => isset( $settings['application'] ) && !empty( $settings['application'] ) ? esc_url_raw( $settings['application'] ) : null,
            'email'     => isset( $settings['email'] ) && !empty( $settings['email'] ) ? esc_attr( $settings['email'] ) : null,
            'social' => array(
                'facebook'  => isset( $settings['facebook'] ) && !empty( $settings['facebook'] ) ? esc_url_raw( $settings['facebook'] ) : null,
                'twitter'   => isset( $settings['twitter'] ) && !empty( $settings['twitter'] ) ? esc_url_raw( $settings['twitter'] ) : null,
                'instagram' => isset( $settings['instagram'] ) && !empty( $settings['instagram'] ) ? esc_url_raw( $settings['instagram'] ) : null,
                'pinterest' => isset( $settings['pinterest'] ) && !empty( $settings['pinterest'] ) ? esc_url_raw( $settings['pinterest'] ) : null,
                'gplus'     => isset( $settings['gplus'] ) && !empty( $settings['gplus'] ) ? esc_url_raw( $settings['gplus'] ) : null,
            ),
        );
        return $contacts;
    }

    private function parse_baths( $baths ) {
        return $baths === '' ? '0' : str_replace( '.00', '', $baths );
    }

    private function parse_images( $unit ) {
        $images = array();
        // If image 1 is set
        $images[] = sprintf( 'http://unitavailability.rentmanager.com/DisplayImage.aspx?corpid=madpm&dbname=madpm_main.&location=&src=floorplanmain&unitId=%d&tableName=unit', $unit->id );
        if( isset( $unit->image1path ) && !empty( $unit->image1path ) ) {
            $images[] = $unit->image1path;
        }
        // If image 2 is set
        if( isset( $unit->image2path ) && !empty( $unit->image2path ) ) {
            $images[] = $unit->image2path;
        }
        // See if image exists in wordpress
        $args = array(
            'post_type' => 'attachment',
            'name' => sanitize_title( sprintf( 'floorplan-%s', $this->floorplanmain ) ),
            'posts_per_page' => 1,
            'post_status' => 'inherit',
        );
        $header = get_posts( $args );
        $header = !empty( $header ) ? current( $header ) : array();

        if( !empty( $header ) ) {
            $images[] = wp_get_attachment_url( $header->ID );
        }
        // Lastly, if no image is set, use the default
        if( empty( $images ) ) {
            $images[] = sprintf( '%simages/default-thumbnail.jpg', $this->plugin_url );
        }
        return $images;
    }

    private function format_rent( $rent ) {
        $rent = current( $rent );
        return number_format( intval( $rent->amount ) , 2, '.', '' );
    }

    private function parse_meta( $unit ) {
        $defaults = array (
            '1' => array (
                'name'  => 'beds',
                'value' => null,
                ),
            '2' => array (
                'name'  => 'baths',
                'value' => null,
                ),
            '3' => array (
                'name'  => 'denloft',
                'value' => null,
                ),
            '4' => array (
                'name'  => 'description',
                'value' => null,
                ),
            '6' => array (
                'name'  => 'carpetcleaningco',
                'value' => null,
                ),
            '7' => array (
                'name'  => 'location',
                'value' => null,
                ),
            '8' => array (
                'name'  => 'carpetdetails',
                'value' => null,
                ),
            '10' => array (
                'name'  => 'cleaningco',
                'value' => null,
                ),
            '11' => array (
                'name'  => 'primarycontactemail',
                'value' => null,
                ),
            '12' => array (
                'name'  => 'dateputonmarket',
                'value' => null,
                ),
            '13' => array (
                'name'  => 'dishwasherdetails',
                'value' => null,
                ),
            '15' => array (
                'name'  => 'electricaldetails',
                'value' => null,
                ),
            '16' => array (
                'name'  => 'filtersize',
                'value' => null,
                ),
            '17' => array (
                'name'  => 'fireplacedetails',
                'value' => null,
                ),
            '18' => array (
                'name'  => 'furnitureavailable',
                'value' => null,
                ),
            '19' => array (
                'name'  => 'keymaster',
                'value' => null,
                ),
            '21' => array (
                'name'  => 'landlord',
                'value' => null,
                ),
            '22' => array (
                'name'  => 'laundrydetails',
                'value' => null,
                ),
            '23' => array (
                'name'  => 'laundrywasheramount',
                'value' => null,
                ),
            '24' => array (
                'name'  => 'parkingdetails',
                'value' => null,
                ),
            '26' => array (
                'name'  => 'obligations',
                'value' => null,
                ),
            '27' => array (
                'name'  => 'occupancylimit',
                'value' => null,
                ),
            '28' => array (
                'name'  => 'pestproblem',
                'value' => null,
                ),
            '30' => array (
                'name'  => 'securitydeposit',
                'value' => null,
                ),
            '32' => array (
                'name'  => 'roofdetails',
                'value' => null,
                ),
            '33' => array (
                'name'  => 'schools',
                'value' => null,
                ),
            '35' => array (
                'name'  => 'laundryserviceco',
                'value' => null,
                ),
            '36' => array (
                'name'  => 'dockboatcolor',
                'value' => null,
                ),
            '37' => array (
                'name'  => 'docksliplength',
                'value' => null,
                ),
            '38' => array (
                'name'  => 'dockslipwidth',
                'value' => null,
                ),
            '39' => array (
                'name'  => 'dockboatmakemodel',
                'value' => null,
                ),
            '40' => array (
                'name'  => 'dockboatname',
                'value' => null,
                ),
            '41' => array (
                'name'  => 'dockslipnumber',
                'value' => null,
                ),
            '42' => array (
                'name'  => 'dockspecialutilityfee',
                'value' => null,
                ),
            '44' => array (
                'name'  => 'vinyldetails',
                'value' => null,
                ),
            '45' => array (
                'name'  => 'trashday',
                'value' => null,
                ),
            '46' => array (
                'name'  => 'trashremovalresponsibility',
                'value' => null,
                ),
            '47' => array (
                'name'  => 'utilitiesresidentresponsibility',
                'value' => null,
                ),
            '48' => array (
                'name'  => 'waterheaterdetails',
                'value' => null,
                ),
            '49' => array (
                'name'  => 'watersoftnerdetails',
                'value' => null,
                ),
            '50' => array (
                'name'  => 'moveoutnotes',
                'value' => null,
                ),
            '51' => array (
                'name'  => 'moveinnotes',
                'value' => null,
                ),
            '54' => array (
                'name'  => 'mgepin',
                'value' => null,
                ),
            '56' => array (
                'name'  => 'entryaccess',
                'value' => null,
                ),
            '62' => array (
                'name'  => 'issmokefree',
                'value' => null,
                ),
            '64' => array (
                'name'  => 'microwavedetails',
                'value' => null,
                ),
            '65' => array (
                'name'  => 'refrigeratordetails',
                'value' => null,
                ),
            '66' => array (
                'name'  => 'stovedetails',
                'value' => null,
                ),
            '67' => array (
                'name'  => 'washerdetails',
                'value' => null,
                ),
            '68' => array (
                'name'  => 'dryerdetails',
                'value' => null,
                ),
            '69' => array (
                'name'  => 'paintdetails',
                'value' => null,
                ),
            '72' => array (
                'name'  => 'availableaug',
                'value' => null,
                ),
            '73' => array (
                'name'  => 'availableshortterm',
                'value' => null,
                ),
            '74' => array (
                'name'  => 'availablesublet',
                'value' => null,
                ),
            '75' => array (
                'name'  => 'availablefrom',
                'value' => null,
                ),
            '76' => array (
                'name'  => 'availableto',
                'value' => null,
                ),
            '77' => array (
                'name'  => 'manager',
                'value' => null,
                ),
            '78' => array (
                'name'  => 'maintenancemanagedbympm',
                'value' => null,
                ),
            '79' => array (
                'name'  => 'section8',
                'value' => null,
                ),
            '88' => array (
                'name'  => 'parkingwebdetails',
                'value' => null,
                ),
            '89' => array (
                'name'  => 'incomerestrictions',
                'value' => null,
                ),
            '90' => array (
                'name'  => 'availablefuture',
                'value' => null,
                ),
            '91' => array (
                'name'  => 'laundrydryeramount',
                'value' => null,
                ),
            '93' => array (
                'name'  => 'descriptionsublet',
                'value' => null,
                ),
            '96' => array (
                'name'  => 'availablefuturefrom',
                'value' => null,
                ),
            '97' => array (
                'name'  => 'availablefutureto',
                'value' => null,
                ),
            '98' => array (
                'name'  => 'craigslisttitle',
                'value' => null,
                ),
            '99' => array (
                'name'  => 'craigslistprice',
                'value' => null,
                ),
            '100' => array (
                'name'  => 'craigslistnearestcrossstreet',
                'value' => null,
                ),
            '101' => array (
                'name'  => 'craigslistemail',
                'value' => null,
                ),
            '102' => array (
                'name'  => 'craigslistdogsok',
                'value' => null,
                ),
            '103' => array (
                'name'  => 'craigslistcatsok',
                'value' => null,
                ),
            '104' => array (
                'name'  => 'shorttermamount',
                'value' => null,
                ),
            '105' => array (
                'name'  => 'showonapplication',
                'value' => null,
                ),
            '110' => array (
                'name'  => 'pdfpacket',
                'value' => null,
                ),
            '111' => array (
                'name'  => 'paint',
                'value' => null,
                ),
            '112' => array (
                'name'  => 'stove',
                'value' => null,
                ),
            '113' => array (
                'name'  => 'refrigerator',
                'value' => null,
                ),
            '114' => array (
                'name'  => 'microwave',
                'value' => null,
                ),
            '115' => array (
                'name'  => 'washingmachine',
                'value' => null,
                ),
            '116' => array (
                'name'  => 'dryer',
                'value' => null,
                ),
            '117' => array (
                'name'  => 'airconditioner',
                'value' => null,
                ),
            '118' => array (
                'name'  => 'garagedoorcode',
                'value' => null,
                ),
            '119' => array (
                'name'  => 'mailboxnumber',
                'value' => null,
                ),
            '120' => array (
                'name'  => 'forrenttitle',
                'value' => null,
                ),
            '122' => array (
                'name'  => 'price',
                'value' => null,
                ),
            '123' => array (
                'name'  => 'nearestcrossstreet',
                'value' => null,
                ),
            '124' => array (
                'name'  => 'email',
                'value' => null,
                ),
            '125' => array (
                'name'  => 'dogsok',
                'value' => null,
                ),
            '126' => array (
                'name'  => 'catsok',
                'value' => null,
                ),
            '128' => array (
                'name'  => 'checkoutperson',
                'value' => null,
                ),
            '129' => array (
                'name'  => 'availableshortwithrenewoption',
                'value' => null,
                ),
            '131' => array (
                'name'  => 'temporarilyoffmarket',
                'value' => null,
                ),
            '132' => array (
                'name'  => 'showonfrontpage',
                'value' => null,
                ),
            '133' => array (
                'name'  => 'floorplanmain',
                'value' => null,
                ),
            '134' => array (
                'name'  => 'floorplan2',
                'value' => null,
                ),
            '135' => array (
                'name'  => 'floorplan3',
                'value' => null,
                ),
            '136' => array (
                'name'  => 'floorplanlower',
                'value' => null,
                ),
            '137' => array (
                'name'  => 'alwaystrue',
                'value' => null,
                ),
            '138' => array (
                'name'  => 'turnovernotes',
                'value' => null,
                ),
            '141' => array (
                'name'  => 'vt1',
                'value' => null,
                ),
            '142' => array (
                'name'  => 'vt2',
                'value' => null,
                ),
            '143' => array (
                'name'  => 'vt3',
                'value' => null,
                ),
            '144' => array (
                'name'  => 'vt4',
                'value' => null,
                ),
            '145' => array (
                'name'  => 'vt5',
                'value' => null,
                ),
            '146' => array (
                'name'  => 'vt6',
                'value' => null,
                ),
            '147' => array (
                'name'  => 'vt7',
                'value' => null,
                ),
            '148' => array (
                'name'  => 'vt8',
                'value' => null,
                ),
            '149' => array (
                'name'  => 'vt9',
                'value' => null,
                ),
            '150' => array (
                'name'  => 'vt10',
                'value' => null,
                ),
            '151' => array (
                'name'  => 'vt11',
                'value' => null,
                ),
            '152' => array (
                'name'  => 'vt12',
                'value' => null,
                ),
            '153' => array (
                'name'  => 'vt13',
                'value' => null,
                ),
            '154' => array (
                'name'  => 'vt14',
                'value' => null,
                ),
            '155' => array (
                'name'  => 'vt15',
                'value' => null,
                ),
            '156' => array (
                'name'  => 'vt16',
                'value' => null,
                ),
            '157' => array (
                'name'  => 'vt17',
                'value' => null,
                ),
            '158' => array (
                'name'  => 'vt18',
                'value' => null,
                ),
            '159' => array (
                'name'  => 'vt19',
                'value' => null,
                ),
            '160' => array (
                'name'  => 'vt20',
                'value' => null,
                ),
            '161' => array (
                'name'  => 'vtorder1',
                'value' => null,
                ),
            '162' => array (
                'name'  => 'vtorder2',
                'value' => null,
                ),
            '163' => array (
                'name'  => 'vtorder3',
                'value' => null,
                ),
            '164' => array (
                'name'  => 'vtorder4',
                'value' => null,
                ),
            '165' => array (
                'name'  => 'vtorder5',
                'value' => null,
                ),
            '166' => array (
                'name'  => 'vtorder6',
                'value' => null,
                ),
            '167' => array (
                'name'  => 'vtorder7',
                'value' => null,
                ),
            '168' => array (
                'name'  => 'vtorder8',
                'value' => null,
                ),
            '169' => array (
                'name'  => 'vtorder9',
                'value' => null,
                ),
            '170' => array (
                'name'  => 'vtorder10',
                'value' => null,
                ),
            '171' => array (
                'name'  => 'vtorder11',
                'value' => null,
                ),
            '172' => array (
                'name'  => 'vtorder12',
                'value' => null,
                ),
            '173' => array (
                'name'  => 'vtorder13',
                'value' => null,
                ),
            '174' => array (
                'name'  => 'vtorder14',
                'value' => null,
                ),
            '175' => array (
                'name'  => 'vtorder15',
                'value' => null,
                ),
            '176' => array (
                'name'  => 'vtorder16',
                'value' => null,
                ),
            '177' => array (
                'name'  => 'vtorder17',
                'value' => null,
                ),
            '178' => array (
                'name'  => 'vtorder18',
                'value' => null,
                ),
            '179' => array (
                'name'  => 'vtorder19',
                'value' => null,
                ),
            '180' => array (
                'name'  => 'vtorder20',
                'value' => null,
                ),
            '181' => array (
                'name'  => 'vttitle1',
                'value' => null,
                ),
            '182' => array (
                'name'  => 'vttitle2',
                'value' => null,
                ),
            '183' => array (
                'name'  => 'vttitle3',
                'value' => null,
                ),
            '184' => array (
                'name'  => 'vttitle4',
                'value' => null,
                ),
            '185' => array (
                'name'  => 'vttitle5',
                'value' => null,
                ),
            '186' => array (
                'name'  => 'vttitle6',
                'value' => null,
                ),
            '187' => array (
                'name'  => 'vttitle7',
                'value' => null,
                ),
            '188' => array (
                'name'  => 'vttitle8',
                'value' => null,
                ),
            '189' => array (
                'name'  => 'vttitle9',
                'value' => null,
                ),
            '190' => array (
                'name'  => 'vttitle10',
                'value' => null,
                ),
            '191' => array (
                'name'  => 'vttitle11',
                'value' => null,
                ),
            '192' => array (
                'name'  => 'vttitle12',
                'value' => null,
                ),
            '193' => array (
                'name'  => 'vttitle13',
                'value' => null,
                ),
            '194' => array (
                'name'  => 'vttitle14',
                'value' => null,
                ),
            '195' => array (
                'name'  => 'vttitle15',
                'value' => null,
                ),
            '196' => array (
                'name'  => 'vttitle16',
                'value' => null,
                ),
            '197' => array (
                'name'  => 'vttitle17',
                'value' => null,
                ),
            '198' => array (
                'name'  => 'vttitle18',
                'value' => null,
                ),
            '199' => array (
                'name'  => 'vttitle19',
                'value' => null,
                ),
            '200' => array (
                'name'  => 'vttitle20',
                'value' => null,
                ),
            '201' => array (
                'name'  => 'frontpage1',
                'value' => null,
                ),
            '202' => array (
                'name'  => 'frontpage2',
                'value' => null,
                ),
            '203' => array (
                'name'  => 'frontpage3',
                'value' => null,
                ),
            '204' => array (
                'name'  => 'frontpage4',
                'value' => null,
                ),
            '205' => array (
                'name'  => 'frontpage5',
                'value' => null,
                ),
            '206' => array (
                'name'  => 'frontpage6',
                'value' => null,
                ),
            '207' => array (
                'name'  => 'frontpage7',
                'value' => null,
                ),
            '208' => array (
                'name'  => 'frontpage8',
                'value' => null,
                ),
            '209' => array (
                'name'  => 'frontpage9',
                'value' => null,
                ),
            '210' => array (
                'name'  => 'nolongermanaging',
                'value' => null,
                ),
            '211' => array (
                'name'  => 'laundrynearbylocation',
                'value' => null,
                ),
            '212' => array (
                'name'  => 'frontpage10',
                'value' => null,
                ),
            '213' => array (
                'name'  => 'commercialunitsubtype',
                'value' => null,
                ),
            '214' => array (
                'name'  => 'parkingunitsubtype',
                'value' => null,
                ),
            '215' => array (
                'name'  => 'paintingco',
                'value' => null,
                ),
            '216' => array (
                'name'  => 'unitfloorplantype',
                'value' => null,
                ),
            '217' => array (
                'name'  => 'dishwasheryearreplaced',
                'value' => null,
                ),
            '218' => array (
                'name'  => 'microwaveyearreplaced',
                'value' => null,
                ),
            '219' => array (
                'name'  => 'stoveyearreplaced',
                'value' => null,
                ),
            '220' => array (
                'name'  => 'refrigeratoryearreplaced',
                'value' => null,
                ),
            '221' => array (
                'name'  => 'washeryearreplaced',
                'value' => null,
                ),
            '222' => array (
                'name'  => 'dryeryearreplaced',
                'value' => null,
                ),
            '223' => array (
                'name'  => 'flooringlivingroom',
                'value' => null,
                ),
            '224' => array (
                'name'  => 'flooringkitchen',
                'value' => null,
                ),
            '225' => array (
                'name'  => 'flooringbath1',
                'value' => null,
                ),
            '226' => array (
                'name'  => 'flooringbath2',
                'value' => null,
                ),
            '227' => array (
                'name'  => 'flooringbath3',
                'value' => null,
                ),
            '228' => array (
                'name'  => 'flooringbedrooma',
                'value' => null,
                ),
            '229' => array (
                'name'  => 'flooringbedroomb',
                'value' => null,
                ),
            '230' => array (
                'name'  => 'flooringbedroomc',
                'value' => null,
                ),
            '231' => array (
                'name'  => 'flooringbedroomd',
                'value' => null,
                ),
            '232' => array (
                'name'  => 'flooringbedroome',
                'value' => null,
                ),
            '233' => array (
                'name'  => 'flooringbedroomf',
                'value' => null,
                ),
            '234' => array (
                'name'  => 'flooringbedroomg',
                'value' => null,
                ),
            '235' => array (
                'name'  => 'flooringhallway',
                'value' => null,
                ),
            '236' => array (
                'name'  => 'flooringstairs',
                'value' => null,
                ),
            '237' => array (
                'name'  => 'flooringbasementfamilyroom',
                'value' => null,
                ),
            '238' => array (
                'name'  => 'flooringden',
                'value' => null,
                ),
            '239' => array (
                'name'  => 'flooringporch',
                'value' => null,
                ),
            '240' => array (
                'name'  => 'flooringlivingroomyearreplaced',
                'value' => null,
                ),
            '241' => array (
                'name'  => 'flooringkitchenyearreplaced',
                'value' => null,
                ),
            '242' => array (
                'name'  => 'flooringbath1yearreplaced',
                'value' => null,
                ),
            '243' => array (
                'name'  => 'flooringbath2yearreplaced',
                'value' => null,
                ),
            '244' => array (
                'name'  => 'flooringbath3yearreplaced',
                'value' => null,
                ),
            '245' => array (
                'name'  => 'flooringbedroomayearreplaced',
                'value' => null,
                ),
            '246' => array (
                'name'  => 'flooringbedroombyearreplaced',
                'value' => null,
                ),
            '247' => array (
                'name'  => 'flooringbedroomcyearreplaced',
                'value' => null,
                ),
            '248' => array (
                'name'  => 'flooringbedroomdyearreplaced',
                'value' => null,
                ),
            '249' => array (
                'name'  => 'flooringbedroomeyearreplaced',
                'value' => null,
                ),
            '250' => array (
                'name'  => 'flooringbedroomfyearreplaced',
                'value' => null,
                ),
            '251' => array (
                'name'  => 'flooringbedroomgyearreplaced',
                'value' => null,
                ),
            '252' => array (
                'name'  => 'flooringhallwayyearreplaced',
                'value' => null,
                ),
            '253' => array (
                'name'  => 'flooringstairsyearreplaced',
                'value' => null,
                ),
            '254' => array (
                'name'  => 'flooringbasementfamilyroomyearreplaced',
                'value' => null,
                ),
            '255' => array (
                'name'  => 'flooringdenyearreplaced',
                'value' => null,
                ),
            '256' => array (
                'name'  => 'flooringporchyearreplaced',
                'value' => null,
                ),
            '257' => array (
                'name'  => 'airconditioneryearreplaced',
                'value' => null,
                ),
            '258' => array (
                'name'  => 'waterhearteryearreplaced',
                'value' => null,
                ),
            '259' => array (
                'name'  => 'watersofteneryearreplaced',
                'value' => null,
                ),
            '260' => array (
                'name'  => 'flooringbedroomh',
                'value' => null,
                ),
            '261' => array (
                'name'  => 'flooringloft',
                'value' => null,
                ),
            '262' => array (
                'name'  => 'flooringbedroomhyearreplaced',
                'value' => null,
                ),
            '263' => array (
                'name'  => 'flooringloftyearreplaced',
                'value' => null,
                ),
            '264' => array (
                'name'  => 'parkingcompactcaronly',
                'value' => null,
                ),
            '265' => array (
                'name'  => 'parkingrestrictedhours',
                'value' => null,
                ),
            '266' => array (
                'name'  => 'parkingmotorcycleonly',
                'value' => null,
                ),
            '267' => array (
                'name'  => 'availablesublet2',
                'value' => null,
                ),
            '268' => array (
                'name'  => 'availableshortterm2',
                'value' => null,
                ),
            '269' => array (
                'name'  => 'availableshortwithrenewoption2',
                'value' => null,
                ),
            '270' => array (
                'name'  => 'availablefrom2',
                'value' => null,
                ),
            '271' => array (
                'name'  => 'availableto2',
                'value' => null,
                ),
            '272' => array (
                'name'  => 'shorttermamount2',
                'value' => null,
                ),
            '273' => array (
                'name'  => 'descriptionsublet2',
                'value' => null,
                ),
            );
        $meta = array();
        foreach( $defaults as $index => $default ) {
            $this->{$default['name']} = isset( $unit->meta[$index] ) ? $unit->meta[$index]->value : $default['value'];
        }
        // return (object)$meta;
    }
} // end class