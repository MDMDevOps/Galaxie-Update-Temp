<?php

/**
 * Defines admin functions
 * @link  http://midwestfamilymarketing.com
 * @since 1.0.0
 */

class Mdm_Galaxie_Connector_Admin extends Mdm_Galaxie_Connector {

    /**
     * Constructor Function
     * Calls parent constructor, which sets common fields
     * @since 1.0.0
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Enqueue admin site css files
     * @since 1.0.0
     * @see https://developer.wordpress.org/reference/functions/wp_enqueue_style/
     */
    public function enqueue_styles() {
        wp_enqueue_style( sprintf( '%s_admin', $this->plugin_name ), $this->plugin_url . 'styles/dist/admin.min.css', array(), $this->plugin_version, 'all' );
    }

    /**
     * Enqueue and localize admin site javascript
     * @since 1.0.0
     * @see https://developer.wordpress.org/reference/functions/wp_enqueue_script/
     * @see https://developer.wordpress.org/reference/functions/wp_localize_script/
     */
    public function enqueue_scripts() {
        wp_enqueue_script( sprintf( '%s_admin', $this->plugin_name ), $this->plugin_url . 'scripts/dist/admin.min.js', array( 'jquery' ), $this->plugin_version, true );
        wp_localize_script( sprintf( '%s_admin', $this->plugin_name ), 'wpgcajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
    }

    /**
     * Admin notices
     * Display notices to users on the admin interface
     * @since 1.0.0
     * @see https://codex.wordpress.org/Plugin_API/Action_Reference/admin_notices
     */
    public function admin_notices() {
        // set conditions for admin notices here
    }

    public function clear_error_log() {
        try {
            file_put_contents( $this->plugin_path . 'logs/error.log', '' );
            echo json_encode(true);
            exit();
        } catch (Exception $e) {
            echo json_encode(false);
            exit();
        }
    }

    public function clear_unit_cache() {
        try {
            delete_transient( sprintf( '%s_units', $this->plugin_name ) );
            echo json_encode(true);
            exit();
        } catch (Exception $e) {
            echo json_encode(false);
            exit();
        }
    }
} // end class