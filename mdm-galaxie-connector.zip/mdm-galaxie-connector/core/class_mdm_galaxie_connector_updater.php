<?php

/**
 * Defines udpater functions
 * @link  http://midwestfamilymarketing.com
 * @since 1.0.0
 */

class Mdm_Galaxie_Connector_Updater extends Mdm_Galaxie_Connector {

    /**
     * Username
     * @since 1.0.0
     * @access protected
     * @var (string) $username : Github username
     */
    protected $username;

    /**
     * Repository
     * @since 1.0.0
     * @access protected
     * @var (string) $repository : Github repository name
     */
    protected $repository;

    /**
     * Active
     * @since 1.0.0
     * @access protected
     * @var (string) $active : Plugin status
     */
    protected $active;

    /**
     * Authorization Token
     * @since 1.0.0
     * @access protected
     * @var (string) $authorize_token : Github personal access token
     */
    protected $authorize_token;

    /**
     * Github Response
     * @since 1.0.0
     * @access protected
     * @var (string) $github_response : Response from github API
     */
    protected $github_response;

    /**
     * Constructor Function
     * Calls parent constructor, which sets common fields
     * @since 1.0.0
     */
    public function __construct() {
        $this->username     = 'MDMDevOps';
        $this->repository   = 'mdm-galaxie-db-connector';

        parent::__construct();
    }

    public function set_authorization_token() {
        // Set api key from settings, dependent on multisite installation or not
        $options = get_site_option( $this->plugin_name, array(), true );

        // Determine if we have an api key
        $this->authorize_token = ( isset( $options['api_key'] ) ) ? esc_attr( $options['api_key'] ) : false;
    }
    public function set_plugin_properties() {
        $this->plugin   = get_plugin_data( $this->plugin_file );
        $this->active   = is_plugin_active( $this->plugin_slug );
    }
    /**
     * Get repository data From Gethub
     * @since 1.0.0
     */
    private function get_repository_data() {
        // 1: Check if response is already set
        if( !is_null( $this->github_response ) ) {
            return;
        }
        // Make sure we have an authorization token
        if( !isset( $this->authorize_token ) ) {
            $this->set_authorization_token();
        }
        // If authorization token is false, let's bail...
        if( $this->authorize_token === false ) {
            return;
        }

        // Build request URI
        $request_uri = sprintf( 'https://api.github.com/repos/%s/%s/releases', $this->username, $this->repository );
        // Check if access token is set
        if( $this->authorize_token ) {
            // Append access token to URI
            $request_uri = add_query_arg( 'access_token', $this->authorize_token, $request_uri ); // Append it
        }
        // Get json response from github and parse it
        $response = json_decode( wp_remote_retrieve_body( wp_remote_get( $request_uri ) ), true );
        // If it is an array, get the first item
        if( is_array( $response ) ) {
            $response = current( $response );
        }
        // Check if access token is set
        if( $this->authorize_token ) {
            // Append access token to zipball URL
            $response['zipball_url'] = add_query_arg( 'access_token', $this->authorize_token, $response['zipball_url'] );
        }
        // Set github response
        $this->github_response = $response;

    }

    public function modify_transient( $transient ) {
         // Check if transient has a checked property
        if( property_exists( $transient, 'checked') ) {
             // Did Wordpress check for updates?
            if( $checked = $transient->checked ) {
                $this->get_repository_data(); // Get the repo info
                $out_of_date = version_compare( $this->github_response['tag_name'], $checked[ $this->plugin_slug ], 'gt' ); // Check if we're out of date

                if( $out_of_date ) {

                    $new_files = $this->github_response['zipball_url']; // Get the ZIP

                    $slug = current( explode('/', $this->plugin_slug ) ); // Create valid slug

                    $plugin = array( // setup our plugin info
                        'url' => $this->plugin["PluginURI"],
                        'slug' => $slug,
                        'package' => $new_files,
                        'new_version' => $this->github_response['tag_name']
                    );
                    $transient->response[$this->plugin_slug] = (object) $plugin; // Return it in response
                }
            }
        }
        return $transient; // Return filtered transient
    }
    public function plugin_popup( $result, $action, $args ) {
        if( !empty( $args->slug ) ) { // If there is a slug
            if( $args->slug == $this->plugin_slug ) { // And it's our slug
                $this->get_repository_data(); // Get our repo info
                // Set it to an array
                $plugin = array(
                    'name'              => $this->plugin["Name"],
                    'slug'              => $this->plugin_slug,
                    'version'           => $this->github_response['tag_name'],
                    'author'            => $this->plugin["AuthorName"],
                    'author_profile'    => $this->plugin["AuthorURI"],
                    'last_updated'      => $this->github_response['published_at'],
                    'homepage'          => $this->plugin["PluginURI"],
                    'short_description' => $this->plugin["Description"],
                    'sections'          => array(
                        'Description'   => $this->plugin["Description"],
                        'Updates'       => $this->github_response['body'],
                    ),
                    'download_link'     => $this->github_response['zipball_url'],
                    'action'            => $action
                );
                return (object) $plugin; // Return the data
            }
        }
        return $result; // Otherwise return default
    }
    public function after_install( $response, $hook_extra, $result ) {
        // 1: Get the global filesystem object
        global $wp_filesystem;
        // 2: Get the plugin directory path
        $install_directory = plugin_dir_path( $this->plugin_file );
        // 3: Move files to the plugin
        $wp_filesystem->move( $result['destination'], $install_directory );
        // 4. Set the destination for the rest of the stack
        $result['destination'] = $install_directory;
        // 5. If it was active, re-activate
        if ( $this->active ) {
            activate_plugin( $this->plugin_slug );
        }
        return $result;
    }
} // end class