<?php
/**
 * The header for our theme.
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package mpress
 */
?>

<!DOCTYPE html>
<!--[if lt IE 7 ]>  <html lang="en" class="no-js ie6">  <![endif]-->
<!--[if IE 7 ]>     <html lang="en" class="no-js ie7">  <![endif]-->
<!--[if IE 8 ]>     <html lang="en" class="no-js ie8">  <![endif]-->
<!--[if IE 9 ]>     <html lang="en" class="no-js ie9">  <![endif]-->
<!--[if IE 10 ]>    <html lang="en" class="no-js ie10"> <![endif]-->
<!--[if (gt IE 10)|!(IE)]><!--> <html <?php language_attributes(); ?> class="no-js"> <!--<![endif]-->
<head>
    <!-- define character set -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <!-- XFN Metadata Profile -->
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <!-- mobile specific metadeta -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- specify IE rendering version -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <!-- Wordpress pingback url -->
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
    <!-- Wordpress generated head area -->
    <?php wp_head(); ?>
</head>

<?php if ( $background = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'full' ) ) : ?>

	<body class="landing has-bg" <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage" style="background-image: url('<?php echo $background[0]; ?>');">

<?php else : ?>

	<body class="landing landing-sub" <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">

<?php endif; ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', MPRESS_THEME_NAME ); ?></a>


    <header id="masthead" role="banner">
        <div class="wrapper">
            <div class="site-branding column md-3" itemprop="publisher" itemscope itemtype="https://schema.org/Organization">
                <?php
                    if( get_theme_mod( 'mpress_site_logo', null ) ) {
                        $logo        = sprintf( '<img src="%1$s" alt="%2$s" title="%3$s" itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">', esc_url_raw( get_theme_mod( 'mpress_site_logo') ), get_bloginfo( 'name' ), get_bloginfo( 'description' ) );
                        $title_class = 'site-title has-logo';
                    } else {
                        $logo        = sprintf( '<span class="anchor-text">%s</span>', get_bloginfo( 'name' ) );
                        $title_class = 'site-title';
                    }
                    $title_type  = ( is_front_page() || is_home() ) ? 'h1' : 'h2';
                    // Finally, echo output
                    echo sprintf( '<%1$s class="%2$s"><a href="%3$s" rel="home" itemprop="url">%4$s</a></%1$s>', $title_type, $title_class,  esc_url( home_url( '/' ) ), $logo);
                    echo sprintf( '<meta itemprop="name" content="%s">', get_bloginfo( 'name' ) );
                ?>
            </div><!-- .site-branding -->

            <nav id="landing-navigation" class="<?php echo sprintf( 'main-navigation-bar %s', get_theme_mod( 'mpress_mobile_menu', 'menu-simple' ) ); ?> column md-9" role="navigation" itemscope itemtype="https://schema.org/SiteNavigationElement" aria-expanded="false">
                <?php wp_nav_menu( array( 'theme_location' => 'landing-nav', 'container' => '' ) ); ?>
            </nav><!-- #site-navigation -->

        </div>
    </header><!-- #masthead -->

    <div id="page" class="hfeed site">
        <div id="content" class="site-content">
