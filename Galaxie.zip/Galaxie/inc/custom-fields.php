<?php
/**
 * mpress Theme Custom Fields.
 * @package mpress
 */
 
 
 
add_action( 'cmb2_admin_init', 'galaxie_register_page_options' );

function galaxie_register_page_options() {
	// Start with an underscore to hide fields from custom fields list
	$prefix = 'galaxie_options_';
	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_options = new_cmb2_box( array(
		'id'           => $prefix . 'options',
		'title'        => __( 'Page Options', 'cmb2' ),
		'object_types' => array( 'page', ), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
	) );
	$cmb_options->add_field( array(
		'name' => __( 'Slider ID', 'cmb2' ),
		'id'   => $prefix . 'slider',
		'type' => 'text',
	) );
	$cmb_options->add_field( array(
		'name' => __( 'Mobile Slider ID', 'cmb2' ),
		'desc' => 'Enter only if there is a different slider for mobile.',
		'id'   => $prefix . 'mobileslider',
		'type' => 'text',
	) );
}


add_action( 'cmb2_admin_init', 'galaxie_register_map_options', 9999 );

function galaxie_register_map_options() {
	// Start with an underscore to hide fields from custom fields list
	$prefix = 'galaxie_map_options_';
	/**
	 * Metabox to be displayed on a single page ID
	 */
	$cmb_map = new_cmb2_box( array(
		'id'           => $prefix . 'options',
		'type'        => 'group',
		'title'        => __( 'Map Options', 'cmb2' ),
		'object_types' => array( 'page', ), // Post type
		'show_on'      => array( 'key' => 'page-template', 'value' => 'templates/custom.php' ),
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		'rows_limit'   => 3, // custom attribute to use in our JS
	) );
	$cmb_map->add_field( array(
		'name' => __( 'Default Map ID', 'cmb2' ),
		'id'   => $prefix . 'defaultmap',
		'type' => 'text',
	) );
	$group_field_id = $cmb_map->add_field( array(
		'id'          => 'mapgroup',
		'type'        => 'group',
		'description' => __( 'Generates Maps', 'cmb' ),
		'options'     => array(
			'group_title'   => __( 'Map {#}', 'cmb' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => __( 'Add Another Map', 'cmb' ),
			'remove_button' => __( 'Remove Map', 'cmb' ),
			'sortable'      => true, // beta
		),
	) );
	$cmb_map->add_group_field( $group_field_id, array(
		'name' => __( 'Map Title', 'cmb2' ),
		'id'   => $prefix . 'maptitle',
		'type' => 'text',
	) );
	$cmb_map->add_group_field( $group_field_id, array(
		'name' => __( 'Map ID', 'cmb2' ),
		'id'   => $prefix . 'map',
		'type' => 'text',
	) );
}