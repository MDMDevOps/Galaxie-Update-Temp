<?php
/**
 * Custom template tags for this theme.
 * Eventually, some of the functionality here could be replaced by core features.
 * @package mpress
 */

/**
 * Get Icons
 * Maintains map of icons used for this theme
 * @since  version 1.0.0
 * @param  (string) $icon   : Name of icon
 * @param  (bool)   $return : whether or not to return a string with icon markup
 * @return (string)         : Icon markup
 */
if( !function_exists( 'get_mpress_icon' ) ) {
    function get_mpress_icon( $icon = null, $return = true ) {
        // If no icon request is passed in, just bail
        if( !$icon ) {
            return false;
        }
        // If user specifies return false, do that
        if( !$return )  {
            return null;
        }
        $icon_map = array(
            'twitter'     => '<span class="icon fa fa-twitter"><span>',
            'facebook'    => '<span class="icon fa fa-facebook"><span>',
            'googleplus'  => '<span class="icon fa fa-google-plus"><span>',
            'youtube'     => '<span class="icon fa fa-youtube"><span>',
            'pinterest'   => '<span class="icon fa fa-pinterest"><span>',
            'linkedin'    => '<span class="icon fa fa-linkedin"><span>',
            'author'      => '<span class="icon fa fa-user"></span>',
            'time'        => '<span class="icon fa fa-clock-o"></span>',
            'category'    => '<span class="icon fa fa-tags"></span>',
            'tag'         => '<span class="icon fa fa-hashtag"></span>',
            'comment'     => '<span class="icon fa fa-comments"></span>',
            'edit'        => '<span class="icon fa fa-pencil"></span>',
        );

        if( isset( $icon_map[ strtolower( $icon ) ] ) ) {
            return $icon_map[ strtolower( $icon ) ];
        }
        return false;
    }
}
/* -------------------------------------------------------------------------- */

/**
 * Prints HTML with meta information for the current post / page / etc
 * @since  version 1.0.0
 * @param  (array) $args : Array of which information to print
 * @param  (bool)  $icon : Whether to include icons or not
 */
if ( !function_exists( 'mpress_entry_meta' ) ) {
    function mpress_entry_meta( $args = array(), $icon = true ) {
        // If no arguments are passed, assume they want everything
        if( empty( $args ) ) {
            $default_args = array(
                'author'      => true,
                'date'        => true,
                'category'    => true,
                'tags'        => true,
                'comments'    => true,
                'edit'        => true,
                'date_format' => null
            );
        }
        // Else if ANY arguments are passed, assume they only want those
        else {
            $default_args = array(
                'author'      => false,
                'date'        => false,
                'category'    => false,
                'tags'        => false,
                'comments'    => false,
                'edit'        => false,
                'date_format' => null
            );
        }
        // Merge defaults with passed args, if any
        $args = ( !empty( $args ) ) ? array_merge( $default_args, $args ) : $default_args;

        // Begin output
        $output = '<ul class="mpress_entry_meta">';
        // Author output
        if( $args['author'] ) {
            $output .= sprintf( '<li class="author vcard">%s<span itemprop="author" itemscope itemtype="https://schema.org/Person"><a itemprop="url" href="%s"><span itemprop="name">%s</span></a></span></li>', get_mpress_icon( 'author', $icon ), esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ), esc_html( get_the_author() ) );
        }

        // Form date output
        if( $args['date'] ) {
            // Structure post date
            $post_date  = sprintf( '<time class="entry-date published updated" datetime="%1$s" itemprop="datePublished">%2$s</time>', esc_attr( get_the_date( 'c' ) ), esc_html( get_the_date( $args['date_format'] ) ) );
            // If necessary, append the updated datetime
            $post_date .= ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) ? sprintf( '<time class="updated screen-reader-text" datetime="%1$s" itemprop="dateModified">%2$s</time>', esc_attr( get_the_modified_date( 'c' ) ), esc_html( get_the_modified_date( $args['date_format'] ) ) ) : '';
            // Structure output
            $output .= sprintf( '<li class="date">%s<a href="%s" rel="bookmark">%s</a></li>', get_mpress_icon( 'time', $icon ), esc_url_raw( get_permalink() ), $post_date );
        } // end if date

        // Form category output
        if( $args['category'] ) {
            $output .= sprintf( '<li class="category">%s<span itemprop="keywords">%s</span></li>', get_mpress_icon( 'category', $icon ), get_the_category_list( '</span>, <span itemprop="keywords">' ) );
        }

        // Form tags output
        if( $args['tags'] && has_tag() ) {
            $output .= sprintf( '<li class="tags">%s</li>', get_the_tag_list( sprintf( '%s<span itemprop="keywords">', get_mpress_icon( 'tag', $icon ) ), '</span>, <span itemprop="keywords">', '</span>' ) );
        }

        // Form comments output
        if( $args['comments'] ) {
            $comments = get_comments_number();
            if( comments_open() && !is_null( $comments ) ) {
                // Create output based on number of comments to output
                switch( $comments ) {
                    case 0 :
                        $comment_output = sprintf( '<span class="screen-reader-text" itemprop="commentCount">%d</span>%s', $comments, __( 'No Comments', 'mpress' ) );
                        break;
                    case 1 :
                        $comment_output = __( 'One Comment', 'mpress' );
                        break;
                    default :
                        $comment_output = sprintf( '<span itemprop="commentCount">%d</span> %s', $comments, __( 'Comments', 'mpress' ) );
                        break;
                } // end switch
                $output .= sprintf( '<li class="comments">%s<a href="%s">%s</a></li>', get_mpress_icon( 'comment', $icon ), esc_url_raw( get_comments_link() ), $comment_output );
            } // end comments_open()
        }
        // Edit Link
        if( $args['edit'] && current_user_can( 'edit_post' ) ) {
            $output .= sprintf( '<li class="edit">%s<a href="%s">%s</a></li>', get_mpress_icon( 'edit', $icon ), get_edit_post_link(), __( 'Edit', 'mpress' ) );
        }
        // Close output
        $output .= '</ul>';
        // Echo to screen
        echo $output;
    }
}
/* -------------------------------------------------------------------------- */

/**
 * Returns true if a blog has more than 1 category.
 * @return bool
 */
function mpress_categorized_blog() {
    if ( false === ( $all_the_cool_cats = get_transient( 'mpress_categories' ) ) ) {
        // Create an array of all the categories that are attached to posts.
        $all_the_cool_cats = get_categories( array(
            'fields'     => 'ids',
            'hide_empty' => 1,

            // We only need to know if there is more than one category.
            'number'     => 2,
        ) );

        // Count the number of categories that are attached to the posts.
        $all_the_cool_cats = count( $all_the_cool_cats );

        set_transient( 'mpress_categories', $all_the_cool_cats );
    }

    if ( $all_the_cool_cats > 1 ) {
        // This blog has more than 1 category so mpress_categorized_blog should return true.
        return true;
    } else {
        // This blog has only 1 category so mpress_categorized_blog should return false.
        return false;
    }
}

/**
 * Flush out the transients used in mpress_categorized_blog.
 */
function mpress_category_transient_flusher() {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    // Like, beat it. Dig?
    delete_transient( 'mpress_categories' );
}
add_action( 'edit_category', 'mpress_category_transient_flusher' );
add_action( 'save_post',     'mpress_category_transient_flusher' );

/**
 * Output breadcrumb navigation
 * @since version 1.1.0
 */
if( !function_exists( 'output_mpress_breadcrumbs' ) ) {
    function output_mpress_breadcrumbs() {
        $microdata = array(
            'li'       => 'itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem"',
            'link'     => 'itemprop="url"',
            'name'     => 'itemprop="name"',
            'position' => '<meta itemprop="position" content="%d" />'
        );
        // Begin output
        $output  = '<ul class="breadcrumbs" itemscope itemtype="http://schema.org/BreadcrumbList">';
        // Output Home link
        $output .= sprintf( '<li %1$s class="home"><a %2$s rel="home" href="%3$s"><span class="icon fa fa-home"></span><span %4$s>%5$s</span></a>%6$s</li>',
            $microdata['li'],
            $microdata['link'],
            esc_url( get_option( 'home' ) ),
            $microdata['name'],
            __( 'Home', 'mpress' ),
            sprintf( $microdata['position'], 1 )
        );

        // Is blog page (not frontpage)
        if( is_home() && !is_front_page() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s</span>%4$s</li>',
                $microdata['li'],
                $microdata['name'],
                __( 'Blog', 'mpress' ),
                sprintf( $microdata['position'], 2 )
            );
        }

        // Single Page (not frontpage)
        elseif( is_page() && !is_front_page() ) {
            // Output page ancesters
            $ancesters = get_post_ancestors( $post );
            if( !empty( $ancesters ) ) {
                // Reverse array for output
                array_reverse( $ancesters );
                $item_count = 2;
                foreach( array_reverse( $ancesters ) as $ancester ) {
                    $output .= sprintf(
                        '<li %s><a %s href="%s" rel="bookmark"><span %s>%s</span></a>%s</li>',
                        $microdata['li'],
                        $microdata['link'],
                        get_the_permalink( $ancester ),
                        $microdata['name'],
                        get_the_title( $ancester ),
                        sprintf(
                            $microdata['position'],
                            $item_count )
                    );
                    $item_count++;
                }
            } // end ancester pages
            // Output this pages title
            $output .= sprintf( '<li %s><span %s>%s</span>%s</li>',
                $microdata['li'],
                $microdata['name'],
                get_the_title(),
                sprintf(
                    $microdata['position'],
                    $item_count
                )
            );
        }

        // Single Post
        elseif( is_single() ) {
            // Output Categories
            $output .= sprintf(
                '<li %s>%s</li>',
                $microdata['li'],
                mpress_get_the_category_list( 2, '</li><li itemprop="item" itemscope itemtype="http://schema.org/ListItem">', 'multiple' )
            );
            // Count the number of categories, including parent / grandparent categories
            $count = mpress_count_the_category_list( 'multiple' ) + 2;
            // Output list item of current post
            $output .= sprintf( '<li %s><span class="%s">%s</span><meta itemprop="position" content="%d"></li>', $microdata['li'], $microdata['name'], get_the_title(), $count );
        }

        // Category archive
        elseif( is_category() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                __( 'Category:', 'mpress' ),
                single_cat_title( '', false ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Tag archive
        elseif( is_tag() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                 __( 'Tag:', 'mpress' ),
                single_tag_title( '', false ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Day archive
        elseif( is_day() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                 __( 'Day:', 'mpress' ),
                get_the_time( 'F jS, Y' ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Month archive
        elseif( is_month() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                 __( 'Month:', 'mpress' ),
                get_the_time( 'F, Y' ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Year archive
        elseif( is_year() ) {
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                 __( 'Year:', 'mpress' ),
                get_the_time( 'Y' ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Author archive
        elseif( is_author() ) {
            $author = get_userdata( get_query_var( 'author' ) );
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                __( 'Author: ', 'mpress' ),
                $author->display_name,
                sprintf( $microdata['position'], 2 )
            );
        }
        // Search page
        elseif( is_search() ) {
            $search = isset( $_GET['s'] ) ? esc_attr( $_GET['s'] ) : null;
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s %4$s</span>%5$s</li>',
                $microdata['li'],
                $microdata['name'],
                __( 'Search Results:', 'mpress' ),
                $search,
                sprintf( $microdata['position'], 2 )
            );
        }
        // 404 Page
        elseif( is_404() ) {
            $output .= sprintf( '<li>%s</li>', __( 'Page Not Found', 'mpress' ) );
            $output .= sprintf(
                '<li %1$s><span %2$s>%3$s</span>%4$s</li>',
                $microdata['li'],
                $microdata['name'],
                __( 'Page Not Found', 'mpress' ),
                sprintf( $microdata['position'], 2 )
            );
        }
        // Close breadcrumbs list
        $output .= '</ul>';
        // Echo output to screen
        echo $output;
    }
    add_action( 'mpress_breadcrumbs', 'output_mpress_breadcrumbs' );
}
/* -------------------------------------------------------------------------- */

/**
* Retrieve category list in either HTML list or custom format.
* Modified version of Wordpress core get_the_category_list()
* Does not alter the behavior of wordpress core function, just gives an alternative funciton to use when needed
* @since 1.1.0
* @global WP_Rewrite $wp_rewrite
* @param  int    $item_pos  : Optional, the starting position of list items
* @param  string $separator : Optional, default is empty string. Separator for between the categories.
* @param  string $parents   : Optional, How to display the parents.
* @param  int    $post_id   : Optional, Post ID to retrieve categories.
* @return string
* @see https://codex.wordpress.org/Function_Reference/get_the_category_list
*/
if( !function_exists( 'mpress_get_the_category_list' ) ) {
    function mpress_get_the_category_list( $item_pos = 0, $separator = '', $parents='', $post_id = false ) {
        global $wp_rewrite;
        if ( ! is_object_in_taxonomy( get_post_type( $post_id ), 'category' ) ) {
            return apply_filters( 'the_category', '', $separator, $parents );
        }
        $categories = apply_filters( 'the_category_list', get_the_category( $post_id ), $post_id );
        if ( empty( $categories ) ) {
            return apply_filters( 'the_category', __( 'Uncategorized' ), $separator, $parents );
        }
        $rel = ( is_object( $wp_rewrite ) && $wp_rewrite->using_permalinks() ) ? 'rel="category tag"' : 'rel="category"';
        $thelist = '';
        if ( '' == $separator ) {
            $thelist .= '<ul class="post-categories">';
            foreach ( $categories as $category ) {
                $thelist .= "\n\t<li>";
                switch ( strtolower( $parents ) ) {
                    case 'multiple' :
                        if ( $category->parent ) {
                            $thelist .= mpress_get_category_parents( $item_pos, $category->parent, true, $separator );
                            $item_pos++;
                        }
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '" ' . $rel . '>' . $category->name.'</a></li>';
                        break;
                    case 'single' :
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '"  ' . $rel . '>';
                        if ( $category->parent )
                            $thelist .= get_category_parents( $category->parent, false, $separator );
                        $thelist .= $category->name.'</a></li>';
                        break;
                    default :
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '" ' . $rel . '>' . $category->name.'</a></li>';
                        break;
                }
            }
            $thelist .= '</ul>';
        } else {
            $i = 0;
            foreach ( $categories as $category ) {
                if ( 0 < $i ) {
                    $thelist .= $separator;
                }
                switch ( strtolower( $parents ) ) {
                    case 'multiple' :
                        if ( $category->parent ) {
                            $thelist .= mpress_get_category_parents( $item_pos, $category->parent, true, $separator );
                            ++$item_pos;
                        }
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '" ' . $rel . '><span itemprop="name">' . $category->name. '</span></a><meta itemprop="position" content="' . $item_pos . '">';
                        break;
                    case 'single' :
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '" ' . $rel . '>';
                        if ( $category->parent )
                                $thelist .= mpress_get_category_parents( $item_pos, $category->parent, false, $separator );
                        $thelist .= "$category->name</a>";
                        break;
                    default :
                        $thelist .= '<a itemprop="url" href="' . esc_url( get_category_link( $category->term_id ) ) . '" ' . $rel . '>' . $category->name.'</a>';
                        break;
                }
                $i++;
                $item_pos++;
            }
        }
        return apply_filters( 'the_category', $thelist, $separator, $parents );
    }
}
/* -------------------------------------------------------------------------- */

/**
* Retrieve category parents with separator.
* Modified version of Wordpress core get_category_parents() required for breadcrumbs
* Does not alter the behavior of wordpress core function, just gives an alternative funciton to use when needed
* @since  1.1.0
* @param  int               $item_pos           : Required, the starting position of list items
* @param  (int)             $id Category ID.    : Required, the category id to retrieve
* @param  (bool)            $link Optional,     : default is false. Whether to format with link.
* @param  (string)          $separator Optional : default is '/'. How to separate categories.
* @param  (bool)            $nicename Optional, : default is false. Whether to use nice name for display.
* @param  (array)           $visited Optional.  : Already linked to categories to prevent duplicates.
* @return (string|WP_Error) A list of category parents on success, WP_Error on failure.
* @see https://codex.wordpress.org/Function_Reference/get_category_parents
*/
if( !function_exists( 'mpress_get_category_parents' ) ) {
    function mpress_get_category_parents( $item_pos = 0, $id, $link = false, $separator = '/', $nicename = false, $visited = array() ) {
        $chain = '';
        $parent = get_term( $id, 'category' );
        if ( is_wp_error( $parent ) ) {
            return $parent;
        }
        if ( $nicename ) {
            $name = $parent->slug;
        }
        else {
            $name = $parent->name;
        }
        if ( $parent->parent && ( $parent->parent != $parent->term_id ) && !in_array( $parent->parent, $visited ) ) {
            $visited[] = $parent->parent;
            $chain .= get_category_parents( $parent->parent, $link, $separator, $nicename, $visited );
        }
        if ( $link ) {
            $chain .= '<a itemprop="url" href="' . esc_url( get_category_link( $parent->term_id ) ) . '"><span itemprop="name">'.$name.'</span></a><meta itemprop="position" content="' . $item_pos . '">' . $separator;
        }
        else {
            $chain .= $name . $separator;
        }
        return $chain;
    }
}
/* -------------------------------------------------------------------------- */

/**
* Count the number of categories for a single post
* @since  1.1.0
* @param  string $parents   : Optional, How to display the parents.
* @param  int    $post_id   : Optional, Post ID to retrieve categories.
*/
if( !function_exists( 'mpress_count_the_category_list' ) ) {
    function mpress_count_the_category_list( $parents='', $post_id = false ) {
        if ( !is_object_in_taxonomy( get_post_type( $post_id ), 'category' ) ) {
            return 0;
        }
        $categories = apply_filters( 'the_category_list', get_the_category( $post_id ), $post_id );
        // If categories are empty, return 0
        if ( empty( $categories ) ) {
            return 0;
        }
        // Count number of categories
        $count = count( $categories );
        // If multiple is selected for parents, add parents to count
        if( strtolower( $parents ) == 'multiple' ) {
            foreach ( $categories as $category ) {
                $count += ( $category->parent ) ? 1 : 0;
            }
        }
        return $count;
    }
}
/* -------------------------------------------------------------------------- */

/**
* Get the menu target for mobile menu link
* @since  1.1.0
*/
if( !function_exists( 'get_mpress_menu_target' ) ) {
    function get_mpress_menu_target() {
        return ( get_theme_mod( 'mpress_mobile_menu', 'menu-simple' ) == 'menu-off-canvas' ) ? '.mobile-menu #off-canvas-page-wrapper' : '#site-navigation';
    }
}

function mpress_social_links() {
    // Build network list
    $output = '<ul class="social-links">';

    foreach( mpress_social_network_settings() as $network => $setting ) {
        // Get setting from database
        $social_uri = get_option( $setting['slug'], null );
        // Append LI if network is set
        if( $social_uri ) {
            $output .= sprintf( '<li class="%1$s"><a class="social-link" href="%2$s" target="_blank">%3$s<span class="screen-reader-text">%1$s</span></a></li>', $network, esc_url_raw( $social_uri ), get_mpress_icon( $network ) );
        }
    }
    $output .= '</ul>';

    echo $output;
}