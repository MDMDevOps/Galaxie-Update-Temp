<?php
/**
 * The sidebar containing the main widget area.
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package mpress
 */
?>
<?php if ( is_active_sidebar( 'landing-sidebar' ) ) : ?>
    <div class="widget-area landing-sidebar" role="complementary">
        <?php dynamic_sidebar( 'landing-sidebar' ); ?>
    </div>
<?php endif; ?>

