<?php
/**
 * Template Name: Landing Tracking Page
 * Description: Templage for displaying homepage
 * @see     https://codex.wordpress.org/Template_Hierarchy
 * @package mpress
 */
?>

<?php get_header('landing-tracking'); ?>

<!-- Google Code for Galaxie Contact Form Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 879299864;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "3gSJCMSH3mcQmJqkowM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/879299864/?label=3gSJCMSH3mcQmJqkowM&amp;guid=ON&amp;script=0"/>
</div>
</noscript> 

<!-- Google Code for Galaxie submission form Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 950321844;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "YJemCOSQgmUQtIWTxQM";
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/950321844/?label=YJemCOSQgmUQtIWTxQM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

<div id="page" class="hfeed site landing-sub">
    <div id="content" class="site-content clearfix">

    
    <main id="main" class="site-main" role="main">

        <?php while ( have_posts() ) : the_post(); ?>
            <?php get_template_part( 'template-parts/content-notitle', 'page' ); ?>
        <?php endwhile;?>

    </main><!-- #main -->
    
    <div class="landing-promo" <?php if ($promotion_padding = get_option('promotion_padding')): ?>style="padding: <?php echo $promotion_padding; ?>;"<?php endif; ?>><?php echo $promotion_text = get_option('promotion_text'); ?></div>
    
	</div><!-- #content -->
</div><!-- #page -->


<?php get_footer('landing'); ?>
