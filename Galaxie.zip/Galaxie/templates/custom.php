<?php
/**
 * Template Name: Page w/ Map Options & Menu
 * Description: Custom Template Boilerplace
 * @see     https://codex.wordpress.org/Template_Hierarchy
 * @package mpress
 */
?>

<?php get_header(); ?>

<?php $slider = get_post_meta( get_the_ID(), 'galaxie_options_slider', true );
$mobileslider = get_post_meta( get_the_ID(), 'galaxie_options_mobileslider', true );
if (  $slider && $mobileslider ) : ?>
	<div class="slider-wrapper mobile"><?php putRevSlider( $mobileslider ) ?></div>
    <div class="slider-wrapper desktop"><?php putRevSlider( $slider ) ?></div>
<?php elseif ( $slider) : ?>
	<div class="slider-wrapper"><?php putRevSlider( $slider ) ?></div>
<?php elseif ( $background = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'full' ) ) : ?>
	<div style="background-image: url('<?php echo $background[0]; ?>');" id="featured-image"></div>
<?php else : ?>
	<div id="no-featured-image"></div>
<?php endif; ?>

<div id="page" class="hfeed site">
    <div id="content" class="site-content clearfix">

    <div id="primary" class="content-area row">
        <main id="main" class="site-main column" role="main">
        
            <nav id="button-navigation" role="navigation" itemscope itemtype="https://schema.org/SiteNavigationElement" aria-expanded="false">
                <?php wp_nav_menu( array( 'theme_location' => 'button-nav', 'container' => '' ) ); ?>
            </nav><!-- #site-navigation -->
            
            <?php while ( have_posts() ) : the_post(); ?>
                <?php get_template_part( 'template-parts/content', 'page' ); ?>
                <?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
            <?php endwhile; // End of the loop. ?>
        </main><!-- #main -->
    </div><!-- #primary -->
    
	</div><!-- #content -->
</div><!-- #page -->


<?php $defaultmap = get_post_meta( get_the_ID(), 'galaxie_map_options_defaultmap', true );
$maps = get_post_meta( get_the_ID(), 'mapgroup', true );?>

<div id="map-title-group" class="wrapper">

	<?php $i = 1;
  foreach ( (array) $maps as $key => $map ) { ?>

        <?php if ( isset( $map['galaxie_map_options_maptitle'] ) ) : ?>
            <div class="column base-6 sm-4 md-3">
                <div class="map-title" data-number="<?php echo $i++; ?>">
                    <div class="map-title-inner">
                        <div class="map-title-wrapper">
                            <div class="title"><?php echo $map['galaxie_map_options_maptitle']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    
    <?php } ?>
        
</div>

<div id="map-group">

        <?php if ( $defaultmap ) : ?>
        	<div class="clearfix map open" data-number="0"><?php echo do_shortcode('[wpgmza id=' . $defaultmap . ']'); ?></div>
        <?php endif; ?>

	<?php $i = 1;
	foreach ( (array) $maps as $key => $map ) { ?>
        
        <?php if ( isset( $map['galaxie_map_options_map'] ) ) : ?>
        	<div class="clearfix map" data-number="<?php echo $i++; ?>"><?php echo do_shortcode('[wpgmza id=' . $map['galaxie_map_options_map'] . ']'); ?></div>
        <?php endif; ?>
    
    <?php } ?>
</div>

<?php get_footer(); ?>