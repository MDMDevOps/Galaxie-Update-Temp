<?php
/**
 * Template Name: Landing Page
 * Description: Templage for displaying homepage
 * @see     https://codex.wordpress.org/Template_Hierarchy
 * @package mpress
 */
?>

<?php get_header('landing'); ?>

<div id="page" class="hfeed site">
    <div id="content" class="site-content">

<?php $slider = get_post_meta( get_the_ID(), 'galaxie_options_slider', true );
$mobileslider = get_post_meta( get_the_ID(), 'galaxie_options_mobileslider', true );
if (  $slider && $mobileslider ) : ?>
	<div class="slider-wrapper mobile"><?php putRevSlider( $mobileslider ) ?></div>
    <div class="slider-wrapper desktop"><?php putRevSlider( $slider ) ?></div>
<?php elseif ( $slider) : ?>
	<div class="slider-wrapper"><?php putRevSlider( $slider ) ?></div>
<?php else : ?>
	<div id="no-featured-image"></div>
<?php endif; ?>
    
    
    <div class="landing-promo" <?php if ($promotion_padding = get_option('promotion_padding')): ?>style="padding: <?php echo $promotion_padding; ?>;"<?php endif; ?>><?php echo $promotion_text = get_option('promotion_text'); ?></div>
    
    
	</div><!-- #content -->
</div><!-- #page -->


<?php get_footer('landing'); ?>
