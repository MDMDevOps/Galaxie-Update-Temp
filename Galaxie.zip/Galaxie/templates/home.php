<?php
/**
 * Template Name: Page w/ No Title
 * Description: Templage for displaying homepage
 * @see     https://codex.wordpress.org/Template_Hierarchy
 * @package mpress
 */
?>

<?php get_header(); ?>

<?php $slider = get_post_meta( get_the_ID(), 'galaxie_options_slider', true );
$mobileslider = get_post_meta( get_the_ID(), 'galaxie_options_mobileslider', true );
if (  $slider && $mobileslider ) : ?>
	<div class="slider-wrapper mobile"><?php putRevSlider( $mobileslider ) ?></div>
    <div class="slider-wrapper desktop"><?php putRevSlider( $slider ) ?></div>
<?php elseif ( $slider) : ?>
	<div class="slider-wrapper"><?php putRevSlider( $slider ) ?></div>
<?php elseif ( $background = wp_get_attachment_image_src( get_post_thumbnail_id( $page->ID ), 'full' ) ) : ?>
	<div style="background-image: url('<?php echo $background[0]; ?>');" id="featured-image"></div>
<?php else : ?>
	<div id="no-featured-image"></div>
<?php endif; ?>

<div id="page" class="hfeed site">
    <div id="content" class="site-content clearfix">

<div id="primary" class="content-area row">

    <main id="main" class="site-main column" role="main">

        <?php while ( have_posts() ) : the_post(); ?>
            <?php get_template_part( 'template-parts/content-notitle', 'page' ); ?>
            <?php if ( comments_open() || get_comments_number() ) : comments_template(); endif; ?>
        <?php endwhile;?>

    </main><!-- #main -->

</div><!-- #primary -->

	</div><!-- #content -->
</div><!-- #page -->

<?php get_footer(); ?>