<?php
/**
 * Template Name: Landing Sub Page
 * Description: Templage for displaying homepage
 * @see     https://codex.wordpress.org/Template_Hierarchy
 * @package mpress
 */
?>

<?php get_header('landing'); ?>

<div id="page" class="hfeed site landing-sub">
    <div id="content" class="site-content clearfix">

    
    <main id="main" class="site-main" role="main">

        <?php while ( have_posts() ) : the_post(); ?>
            <?php get_template_part( 'template-parts/content-notitle', 'page' ); ?>
        <?php endwhile;?>

    </main><!-- #main -->
    
    <div class="landing-promo" <?php if ($promotion_padding = get_option('promotion_padding')): ?>style="padding: <?php echo $promotion_padding; ?>;"<?php endif; ?>><?php echo $promotion_text = get_option('promotion_text'); ?></div>
    
	</div><!-- #content -->
</div><!-- #page -->


<?php get_footer('landing'); ?>
