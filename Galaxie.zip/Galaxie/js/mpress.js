// Protect the global namespace
if( $ ) { $.noConflict(); }
jQuery( document ).ready(function( $ ){
    'use strict';
    /**
     * Breakpoint Indicator Module
     * Used to determine the current breakpoint based on the opacity of the makers-mark image
     * If no mark is present, return false when the breakpoint is queried
     */
    var breakpoints = ( function () {
        // Declare private variables
        var $mark;
        // Initialize
        var init = function() {
            $mark = $( '#makers-mark' );
        };
        // Determine the breakpoint
        var getBreakpoint = function() {
            // If we haven't yet initialized our mark, let's set it
            if( typeof $mark === 'undefined' ) {
                init();
            }
            if( $mark.length === 0 ) {
                return false;
            }
            return $mark.css( 'opacity' ) * 10;
        };
        // Explicitly return methods we want to be publicly available
        return {
            getBreakpoint : getBreakpoint,
        };
    })();

    /**
     * Jumpscroll Module
     * Animate internal jumplinks
     * Attaches to all links with class 'jumpscroll'. Individual links can override speed by using data-scrollspeed
     */
    var JumpLinks = ( function () {
        var links     = $( '.jumpscroll' );
        // Create new jumplinks
        $.each( links, function( index, element ) {
            return new JumpLink( element );
        });
        // Define a single jumplink
        function JumpLink( el ) {
            var $el     = $( el );
            var $hash   = el.hash !== '' ? $( el.hash ) : $( 'body' );
            var $target = $hash.length !== 0 ? $hash : $( 'body' );
            var speed   = $el.data( 'scrollspeed' ) || Math.abs( window.pageYOffset - $target.offset().top ) / 2 || 'slow';
            // Bind Events
            $el.on( 'click', smoothScroll.bind( this ) );
            // Define smooth scroll
            function smoothScroll( event ) {
                event.preventDefault();
                $( 'body, html' ).animate( { scrollTop : $target.offset().top }, speed );
                $el.blur();
            }
        }
    })();


    /**
     * Toggle Button Module
     * Adds behavior to toggle buttons
     */
    var ToggleButtons = ( function () {
        var $body = $( 'body' );
        // Create new buttons
        var $buttons = $.map( $( '.menu-toggle' ), function( element ) {
            return new ToggleButton( element );
        });
        function closeAll() {
            $.each( $buttons, function( index ) {
                $buttons[index].close();
            });
            return;
        }
        return {
            closeAll : closeAll,
        };
       // Define a single buttons behavior
       function ToggleButton( el ) {
            // Cache DOM elements
            var $el             = $( el );
            var targets         = $el.data( 'toggle' );
            var group           = $el.data( 'group' );
            var groupId         = group !== undefined && group !== '' ? group + '-' : '';
            var animate         = $el.data( 'animate' );
            var transitionCount = 0;
            var end             = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend transitionend';
            var complete        = false;
            var $controls       = $( '[data-toggle=' + targets + ']' ).not( '.menu-toggle' ).map( function() {
                return $( this );
            });
            var $group = group !== undefined && group !== '' ? $(  '[data-group=' + group + ']' ).map( function() { return $( this ); } ) : null;
            // Bind events
            $el.on( 'click', toggleState );
            // Define behavior
            function toggleState( event ) {
                event.preventDefault();
                $el.blur();
                transitionCount = 0;
                complete        = false;
                var state = $body.hasClass( groupId + 'open' ) || $body.hasClass( groupId + 'opening' ) ? false : true;
                switch( state ) {
                    case true :
                        $body.addClass( groupId + 'opening' ).removeClass( groupId + 'closed' ).removeClass( groupId + 'closing' );
                        $.each( $controls, function( index, $control ) {
                            openToggle( $control );
                        });
                        break;
                    case false :
                        $body.addClass( groupId + 'closing' ).removeClass( groupId + 'open' ).removeClass( groupId + 'opening' );
                        $.each( $controls, function( index, $control ) {
                            closeToggle( $control );
                        });
                        break;
                    default :
                        $body.addClass( groupId + 'opening' ).removeClass( groupId + 'closed' ).removeClass( groupId + 'closing' );
                        $.each( $controls, function( index, $control ) {
                            openToggle( $control );
                        });
                        break;
                }
                groupToggle( state );
                return;
            }

            function openToggle( $control ) {
                // Add classes to individual elements
                $control.addClass( 'opening' ).removeClass( 'closed closing open' ).one( end, function() {
                    ++transitionCount;
                    $control.addClass( 'open' ).removeClass( 'opening' );
                    if( transitionCount < $controls.length ) {
                        return;
                    }
                    $body.addClass( groupId + 'open' ).removeClass( groupId + 'opening' );
                    complete = true;
                    return;
                });
                // Set timeout in case ending events done fire
                setTimeout( function() {
                    // If transition is already complete, don't run
                    if( complete === true ) {
                        return;
                    }
                    // If the class we need to remove was already removed by something else, let's bail
                    if( !$body.hasClass( groupId + 'opening' ) ) {
                        $control.off( end );
                        return;
                    }
                    // If we made it here, we have some cleanup to do
                    $body.addClass( groupId + 'open' ).removeClass( groupId + 'opening' ).removeClass( groupId + 'closed' ).removeClass( groupId + 'closing' );
                    $control.addClass( 'open' ).removeClass( 'opening closed closing' ).off( end );
                }, 1000 );
                return true;
            }

            function closeToggle( $control ) {
                // Add classes to individual elements
                $control.addClass( 'closing' ).removeClass( 'closed open opening' ).one( end, function() {
                    ++transitionCount;
                    $control.addClass( 'closed' ).removeClass( 'closing' );
                    if( transitionCount < $controls.length ) {
                        return;
                    }
                    $body.addClass( groupId + 'closed' ).removeClass( groupId + 'closing' );
                    complete = true;
                    return;
                });
                // Set timeout in case ending events dont fire
                setTimeout( function() {
                    // If transition is already complete, lets bail
                    if( complete === true ) {
                        return;
                    }
                    // If the class we need to remove was already removed by something else, let's bail
                    if( !$body.hasClass( groupId + 'closing' ) ) {
                        $control.off( end );
                        return;
                    }
                    // If we made it here, we have some cleanup to do
                    $body.addClass( groupId + 'closed' ).removeClass( groupId + 'closing' ).removeClass( groupId + 'open' ).removeClass( groupId + 'opening' );
                    $control.addClass( 'closed' ).removeClass( 'closing open opening' ).off( end );
                }, 1000 );
                return true;
            }

            function groupToggle( state ) {
                // Toggle aria-expanded elements
                if( $group === null ) {
                    return false;
                }
                var addClassName = state === true ? 'open' : 'closed';
                var remClassName = state === true ? 'closed' : 'open';
                $.each( $group, function( index, $el ){
                    $el.attr( 'aria-expanded', state );
                    if( $el.hasClass( 'menu-toggle' ) ) {
                        $el.addClass( addClassName ).removeClass( remClassName );
                    }
                });
            }

            function close() {
                // If it's already closed, let's just bail
                if( $body.hasClass( groupId + 'closed' ) ) {
                    return;
                }
                $body.addClass( groupId + 'closing' ).removeClass( groupId + 'closed' ).removeClass( groupId + 'open' ).removeClass( groupId + 'opening' );
                $.each( $controls, function( index, $control ) {
                    closeToggle( $control );
                });
            }

            return {
                close : close,
            };
        }
    })();

   /**
    * Navigation Module
    * Used to add touch navigation to menu items, as well as dropdown button support
    */
   var Navigation = ( function () {
       // var menuItems = $( '.menu li' );
       // Create new menu item, from each menu items
       var menuItems = $.map( $( '.menu li' ), function( element ) {
           return new menuItem( element );
       });
       // Define how to close all menu items at once
       function closeAll() {
           $.each( menuItems, function( index ) {
               menuItems[index].close();
           });
       }
       return {
           closeAll : closeAll,
       };
       // Define behavior for single menu item
       function menuItem( li ) {
           // Cache DOM elements
           var $li     = $( li );
           var $link   = $li.children( 'a' );
           var $parent = $li.parents( 'ul.sub-menu' );
           var $sub    = $li.children( 'ul' );
           var $last   = $parent.find( 'a' ).last();
           var $toggle = $li.children( '.dropdown-toggle' );
           var $toptog = $parent.find( '.dropdown-toggle' );
           // Bind event handlers
           $toggle.on( 'click', toggleSubMenu );
           $link.on( 'focus', showSubMenu );
           $link.on( 'mousedown', preventFocus );
           $link.on( 'click touchstart', showSubMenu );
           $link.on( 'blur',  blurMenu );
           // $( 'body' ).on( 'click touchstart', blurMenu );
           // Determine if a submenu is visible or not
           function isVisible( $el ) {
               // If has visibility : hidden or display : none, or opacity : 0 -> return false ( not visible )
               if( $el.css( 'visibility') === 'hidden' || $el.css( 'display' ) === 'none' || $el.css( 'opacity' ) === '0' ) {
                   return false;
               }
               return true;
           }
           function preventFocus( event ) {
               if( event.isTrigger === undefined ) {
                   event.preventDefault();
                   return true;
               }
           }
           // Define how toggle buttons handle click events
           function toggleSubMenu( event ) {
               event.preventDefault();
               if( $sub.hasClass( 'focused' ) ) {
                   $sub.removeClass( 'focused' ).attr( 'aria-hidden', 'true' );
                   return true;
               }
               $sub.addClass( 'focused' ).attr( 'aria-hidden', 'false' );
               return false;
           }
           // Define how to handle clicks (for touch support)
           function showSubMenu( event ) {

               // If this has no sub item, there's nothing to do
               if( $sub === undefined ) {
                   return true;
               }

               // If we have toggle buttons, we can let the click pass through
               if( $toggle !== undefined && $toggle.length !== 0 && isVisible( $toggle ) && event.type !== 'focus' ) {
                   return true;
               }

               // If this sub menu is already visible, there's nothing to do
               if( isVisible( $sub ) ) {
                   return true;
               }
               // If we made it here, we can capture the click and open the sub menu instead
               if( event.type !== 'focus' ) {
                   $link.focus();
               }
               event.preventDefault();
               $sub.addClass( 'focused' ).attr( 'aria-hidden', 'false' );
               return false;
           }
           // Define behavior on blur
           function blurMenu( event ) {
               // If there is no parent or sub, we can just bail
               if( $parent === undefined && $sub === undefined ) {
                   return false;
               }
               setTimeout( function() {
                   // Get element that is gaining focus
                   var target = $( ':focus' );
                   // If target is within scope of this nav item, lets bail
                   if( $parent.find( target ).length || $sub.find( target ).length || target.hasClass( 'dropdown-toggle' ) ) {
                       return false;
                   }
                   // If we made it here, let's close the parent & sub
                   $parent.removeClass( 'focused' ).attr( 'aria-hidden', 'true' );
                   $sub.removeClass( 'focused' ).attr( 'aria-hidden', 'true' );
               }, 1 );
               return true;
           }
           // Simple force close
           function close() {
               // If there is no parent or sub, we can just bail
               if( $parent === undefined && $sub === undefined ) {
                   return false;
               }
               $link.blur();
               // If we made it here, let's close the parent & sub
               $parent.removeClass( 'focused' ).attr( 'aria-hidden', 'true' );
               $sub.removeClass( 'focused' ).attr( 'aria-hidden', 'true' );
           }
           // Define methods we expose
           return {
               close : close,
           };
       }
   })();

   // Close All the menu's on window resize
   $( window ).on( 'resize', function( event ) {
       if( event.isTrigger !== undefined ) {
           return;
       }
       ToggleButtons.closeAll();
       Navigation.closeAll();
   });

});