// Protect the global namespace
if( $ ) { $.noConflict(); }
jQuery( document ).ready(function( $ ){
    'use strict';

   // Any other custom function can go here, beyond this point
   //Click event to scroll to top
   $('#scrollToTop').click(function(){
    $('html, body').animate({scrollTop : 0},600);
    return false;
   });
   

    $(window).bind('scroll load', function() {
      if(!$(window).scrollTop()) {
        $('#masthead').removeClass('scrolled');
       }
       else {
         $('#masthead').addClass('scrolled');
       }
    });
	
	$(window).scroll(function() {
	   if($(window).scrollTop() + $(window).height() > $(document).height() - 100) {
        $('#scrollToTop').addClass('bottom');
       }
       else {
         $('#scrollToTop').removeClass('bottom');
       }
	});
	
	
	var mapclickthing = function(){
		
		var $mapGroup = $('#map-group');
		var $titleGroup = $('#map-title-group');
	
		var mapthing = $.map(  $('.map-title'), function( element ) {
			return new MapApp( element );
		});
		
		function MapApp(el) {
			var $el = $( el );
			var mapid = $el.data('number');
			//var $map = $mapGroup.find( '[data-number="' + mapid + '"]');
			var $maps = $mapGroup.find('.map');
			var $titles = $titleGroup.find('.map-title').not(el);
			
			$el.on('click', showMap );
			
			function showMap( event ){
				event.preventDefault();
				$maps.each( function(index, element) {
					var $map = $(element);
					if( $map.data('number') === mapid ) {
						$map.addClass('open');
					} else {
						$map.removeClass('open');
					}
				});
				return;
			}
			
			$el.on('click', showTitle );
			
			function showTitle( event ){
				event.preventDefault();
				$el.addClass('open');
				$titles.each( function(index, element) {
					var $title = $(element);
					$title.removeClass('open');
				});
				return;
			}
		}
	}();
	


});

// Document ready function
jQuery( document ).ready(function($) {
    'use strict';
    // Call touch menu for each menu...
    // Adds dropdownn support AND touch support
    $( '.menu' ).touchMenu();
});