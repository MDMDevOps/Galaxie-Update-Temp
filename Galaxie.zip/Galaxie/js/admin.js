// Document ready function
jQuery( document ).ready(function($) {
    'use strict';
});