<?php
/*******************************************************************************
 *                 ______                 __  _
 *                / ____/_  ______  _____/ /_(_)___  ____  _____
 *               / /_  / / / / __ \/ ___/ __/ / __ \/ __ \/ ___/
 *              / __/ / /_/ / / / / /__/ /_/ / /_/ / / / (__  )
 *             /_/    \__,_/_/ /_/\___/\__/_/\____/_/ /_/____/
 *
 ******************************************************************************/

/**
 * Functions
 * Boostrap all custom functions that our theme needs to run
 * @package mpress
 * @see     https://codex.wordpress.org/Functions_File_Explained
 * @since   version 1.0.0
 */

/**
 * Define constants
 * @since version 1.0.1
 */

define( 'MPRESS_ROOT_DIR', trailingslashit( get_template_directory() ) );     // file path of theme directory
define( 'MPRESS_ROOT_URI', trailingslashit( get_template_directory_uri() ) ); // uri of theme directory
define( 'MPRESS_IMAGES_URI', MPRESS_ROOT_URI . 'images/' );                 // uri to image directory
define( 'MPRESS_SCRIPTS_URI', MPRESS_ROOT_URI . 'js/' );                    // uri to javascript directory
define( 'MPRESS_STYLES_URI', MPRESS_ROOT_URI . 'css/' );                    // uri to stylesheet directory
define( 'MPRESS_INC_DIR', MPRESS_ROOT_DIR . 'inc/' );                       // path to includes directory
define( 'MPRESS_THEME_NAME', 'mpress' );                                    // theme slug used for translation

/* -------------------------------------------------------------------------- */

/**
 * Set Content Width
 * @since version 1.0.0
 * @see   https://codex.wordpress.org/Content_Width
 */
if ( !isset( $content_width ) ) {
    $content_width = 1280;
}
/* -------------------------------------------------------------------------- */

/**
 * Set Social Network settings needed for both customizer, and template tags
 * @since version 1.0.0
 */
if( !function_exists( 'mpress_social_network_settings' ) ) {
    function mpress_social_network_settings() {
        $social = array(
            'facebook' => array(
                'slug'    => 'facebook_uri',
                'default' => null,
                'label'   => __( 'Facebook URI', 'mpress' ),
            ),
            'twitter' => array(
                'slug'    => 'twitter_uri',
                'default' => null,
                'label'   => __( 'Twitter URI', 'mpress' ),
            ),
            'googleplus' => array(
                'slug'    => 'googleplus_uri',
                'default' => null,
                'label'   => __( 'Google Plus URI', 'mpress' ),
            ),
            'youtube' => array(
                'slug'    => 'Youtube_uri',
                'default' => null,
                'label'   => __( 'Youtube URI', 'mpress' ),
            ),
            'linkedin' => array(
                'slug'    => 'linkedin_uri',
                'default' => null,
                'label'   => __( 'Linkedin URI', 'mpress' ),
            ),
            'pinterest' => array(
                'slug'    => 'pinterest_uri',
                'default' => null,
                'label'   => __( 'Pinterest URI', 'mpress' ),
            )
        );
        return $social;
    }
}


/**
 * Include CUSTOM THEME HOOKS
 * Custom theme hooks define things such as shortcodes, and template tags
 */
include MPRESS_INC_DIR . 'hooks.php';

/**
 * Include ACTIONS
 * Where we add our menu's & widgets, enqueue stylehseets and scripts, etc
 * @see https://codex.wordpress.org/Plugin_API/Action_Reference
 */
include MPRESS_INC_DIR . 'actions.php';

/**
 * Include CUSTOM THEME CUSTOM FIELDS
 */
include MPRESS_INC_DIR . 'custom-fields.php';

/**
 * Include DROPDOWN BUTTONS
 */
include MPRESS_INC_DIR . 'append_dropdown_buttons.php';

/**
 * Include FILTERS
 * Where we add our filters, such as removing script versions, adding mimi types, etc
 * @see https://codex.wordpress.org/Plugin_API/Filter_Reference
 */
include MPRESS_INC_DIR . 'filters.php';

/**
 * Include WIDGET(S)
 * Where we define any custom theme widgets
 * ( commented out if not using any, only boilerplate included here )
 */
// include MPRESS_INC_DIR . 'widget-boilerplate/widget.php';

/**
 * Include CUSTOM POST TYPE(S)
 * Where we define any custom post types we need
 */
include MPRESS_INC_DIR . 'content_blocks.php';

/**
 * Custom template tags for this theme.
 */
include MPRESS_INC_DIR . 'template_tags.php';

/**
 * Customizer additions.
 */
include MPRESS_INC_DIR . 'customizer.php';

// include MPRESS_INC_DIR . 'truck-systems/class_truck_systems.php';

/**
 * Load Jetpack compatibility file.
 */
//include MPRESS_INC_DIR . 'jetpack.php';

/**
 * Implement the Custom Header feature.
 */
//include MPRESS_INC_DIR . 'custom_header.php';


/**
 * Implement Gravity Forms field visibility settings.
 */
add_filter( 'gform_enable_field_label_visibility_settings', '__return_true' );