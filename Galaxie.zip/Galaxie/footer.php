<?php
/**
 * The template for displaying the footer.
 * Contains the closing of the #content div and all content after.
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package mpress
 */
?>


<footer id="colophon" class="site-footer" role="contentinfo">
    <div class="site-footer wrapper">
    
            <div id="scrollToTop"></div>
            
            <nav id="footer-navigation" class="column md-4" role="navigation">
                <?php wp_nav_menu( array( 'theme_location' => 'footer-navbar', 'container' => '' ) ); ?>
            </nav><!-- #site-navigation -->
            <div class="site-branding column md-4">
                <?php
                    if( get_theme_mod( 'mpress_site_logo', null ) ) {
                        $logo        = sprintf( '<img src="%1$s" alt="%2$s" title="%3$s" itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">', esc_url_raw( get_theme_mod( 'mpress_site_logo') ), get_bloginfo( 'name' ), get_bloginfo( 'description' ) );
                        $title_class = 'site-title has-logo';
                    } else {
                        $logo        = sprintf( '<span class="anchor-text">%s</span>', get_bloginfo( 'name' ) );
                        $title_class = 'site-title';
                    }
                    $title_type  = ( is_front_page() || is_home() ) ? 'h1' : 'h2';
                    // Finally, echo output
                    echo sprintf( '<%1$s class="%2$s"><a href="%3$s" rel="home" itemprop="url">%4$s</a></%1$s>', $title_type, $title_class,  esc_url( home_url( '/' ) ), $logo);
                    echo sprintf( '<meta itemprop="name" content="%s">', get_bloginfo( 'name' ) );
                ?>
            </div><!-- .site-branding -->

            <div class="site-info column md-4">
            	<a href="http://www.madisonproperty.com/"><img class="mpm-logo" src="<?php echo get_template_directory_uri (); ?>/images/mpm-logo.jpg">Professionally managed by<br>
                Madison Property Management</a>
            </div>
       
    </div><!-- .site-info -->   
         
	<div class="site-copyright">
        <div class="copyright wrapper">
            <a href="<?php echo esc_url( __( 'https://midwestfamilymarketing.com', 'mpress' ) ); ?>"><?php printf( esc_html__( 'Proudly powered by %s', 'mpress' ), 'mpress' ); ?></a>
            <?php printf( esc_html__( '%1$s by %2$s.', 'mpress' ), 'A Wordpress Based CMS', '<a href="http://midwestdigitalmarketing.com" rel="designer">Mid-West Family Marketing</a>' ); ?>
        </div>
    </div><!-- .site-info -->
</footer><!-- #colophon -->

<?php if( get_theme_mod( 'mpress_mobile_menu', 'simple' ) == 'off_canvas' ) { echo '</div>'; } ?>

<?php wp_footer(); ?>

</body>
</html>
